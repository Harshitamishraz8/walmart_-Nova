import type { Store, DistributionCenter, Event, Recommendation } from '../types';

// Linear Programming Solver (Simplified Implementation)
export class LinearProgrammingSolver {
  /**
   * Solve transportation problem using Vogel's Approximation Method
   */
  solveTransportation(
    supply: number[],
    demand: number[],
    costs: number[][],
    constraints: OptimizationConstraints
  ): TransportationSolution {
    const m = supply.length;
    const n = demand.length;
    
    // Create allocation matrix
    const allocation = Array(m).fill(null).map(() => Array(n).fill(0));
    const supplyCopy = [...supply];
    const demandCopy = [...demand];
    
    let totalCost = 0;
    let totalTime = 0;
    
    // Vogel's Approximation Method
    while (supplyCopy.some(s => s > 0) && demandCopy.some(d => d > 0)) {
      const penalties = this.calculatePenalties(costs, supplyCopy, demandCopy);
      const { i, j } = this.selectCell(penalties, costs, supplyCopy, demandCopy);
      
      const allocatedQuantity = Math.min(supplyCopy[i], demandCopy[j]);
      allocation[i][j] = allocatedQuantity;
      
      totalCost += allocatedQuantity * costs[i][j];
      totalTime = Math.max(totalTime, this.calculateTransportTime(i, j, allocatedQuantity));
      
      supplyCopy[i] -= allocatedQuantity;
      demandCopy[j] -= allocatedQuantity;
    }
    
    return {
      allocation,
      totalCost,
      totalTime,
      feasible: this.checkConstraints(allocation, constraints),
      efficiency: this.calculateEfficiency(allocation, costs)
    };
  }

  private calculatePenalties(costs: number[][], supply: number[], demand: number[]): {
    rowPenalties: number[];
    colPenalties: number[];
  } {
    const m = costs.length;
    const n = costs[0].length;
    
    const rowPenalties = Array(m).fill(0);
    const colPenalties = Array(n).fill(0);
    
    // Calculate row penalties
    for (let i = 0; i < m; i++) {
      if (supply[i] > 0) {
        const availableCosts = costs[i].filter((_, j) => demand[j] > 0).sort((a, b) => a - b);
        if (availableCosts.length >= 2) {
          rowPenalties[i] = availableCosts[1] - availableCosts[0];
        }
      }
    }
    
    // Calculate column penalties
    for (let j = 0; j < n; j++) {
      if (demand[j] > 0) {
        const availableCosts = costs.map((row, i) => supply[i] > 0 ? row[j] : Infinity)
          .filter(cost => cost !== Infinity).sort((a, b) => a - b);
        if (availableCosts.length >= 2) {
          colPenalties[j] = availableCosts[1] - availableCosts[0];
        }
      }
    }
    
    return { rowPenalties, colPenalties };
  }

  private selectCell(penalties: any, costs: number[][], supply: number[], demand: number[]): { i: number; j: number } {
    const maxRowPenalty = Math.max(...penalties.rowPenalties);
    const maxColPenalty = Math.max(...penalties.colPenalties);
    
    if (maxRowPenalty >= maxColPenalty) {
      const i = penalties.rowPenalties.indexOf(maxRowPenalty);
      let j = 0;
      let minCost = Infinity;
      
      for (let col = 0; col < costs[i].length; col++) {
        if (demand[col] > 0 && costs[i][col] < minCost) {
          minCost = costs[i][col];
          j = col;
        }
      }
      
      return { i, j };
    } else {
      const j = penalties.colPenalties.indexOf(maxColPenalty);
      let i = 0;
      let minCost = Infinity;
      
      for (let row = 0; row < costs.length; row++) {
        if (supply[row] > 0 && costs[row][j] < minCost) {
          minCost = costs[row][j];
          i = row;
        }
      }
      
      return { i, j };
    }
  }

  private calculateTransportTime(i: number, j: number, quantity: number): number {
    // Simplified time calculation based on distance and quantity
    const baseTime = Math.sqrt((i - j) ** 2) * 2; // Base transport time
    const loadingTime = quantity * 0.1; // Loading time per unit
    return baseTime + loadingTime;
  }

  private checkConstraints(allocation: number[][], constraints: OptimizationConstraints): boolean {
    const totalCost = allocation.reduce((sum, row, i) => 
      sum + row.reduce((rowSum, val, j) => rowSum + val * (i + j + 1), 0), 0
    );
    
    return totalCost <= constraints.maxBudget;
  }

  private calculateEfficiency(allocation: number[][], costs: number[][]): number {
    const totalAllocated = allocation.reduce((sum, row) => sum + row.reduce((a, b) => a + b, 0), 0);
    const totalCost = allocation.reduce((sum, row, i) => 
      sum + row.reduce((rowSum, val, j) => rowSum + val * costs[i][j], 0), 0
    );
    
    return totalAllocated > 0 ? totalAllocated / totalCost : 0;
  }
}

// Heuristic Optimization Algorithms
export class HeuristicOptimizer {
  /**
   * Genetic Algorithm for multi-objective optimization
   */
  geneticAlgorithm(
    problem: OptimizationProblem,
    constraints: OptimizationConstraints,
    generations: number = 100
  ): OptimizationSolution {
    const populationSize = 50;
    let population = this.initializePopulation(populationSize, problem);
    
    for (let gen = 0; gen < generations; gen++) {
      // Evaluate fitness
      const fitness = population.map(individual => this.evaluateFitness(individual, problem, constraints));
      
      // Selection
      const selected = this.tournamentSelection(population, fitness, populationSize / 2);
      
      // Crossover and Mutation
      const offspring = this.crossoverAndMutation(selected, problem);
      
      // Combine and select best
      population = this.selectBest([...selected, ...offspring], problem, constraints, populationSize);
    }
    
    const bestSolution = population[0];
    return this.createOptimizationSolution(bestSolution, problem, constraints);
  }

  private initializePopulation(size: number, problem: OptimizationProblem): Individual[] {
    const population: Individual[] = [];
    
    for (let i = 0; i < size; i++) {
      const individual: Individual = {
        transfers: [],
        routes: [],
        allocations: {}
      };
      
      // Generate random transfers
      for (let j = 0; j < Math.random() * 5 + 1; j++) {
        individual.transfers.push({
          from: Math.floor(Math.random() * problem.sources.length),
          to: Math.floor(Math.random() * problem.destinations.length),
          quantity: Math.floor(Math.random() * 100) + 10
        });
      }
      
      population.push(individual);
    }
    
    return population;
  }

  private evaluateFitness(individual: Individual, problem: OptimizationProblem, constraints: OptimizationConstraints): number {
    let cost = 0;
    let time = 0;
    let satisfaction = 0;
    
    individual.transfers.forEach(transfer => {
      const distance = this.calculateDistance(
        problem.sources[transfer.from],
        problem.destinations[transfer.to]
      );
      
      cost += distance * transfer.quantity * 0.5;
      time += distance * 0.1 + transfer.quantity * 0.05;
      satisfaction += transfer.quantity * 0.8;
    });
    
    // Multi-objective fitness (weighted sum)
    const weights = problem.objective === 'minimize_cost' ? [0.6, 0.3, 0.1] :
                   problem.objective === 'minimize_time' ? [0.2, 0.6, 0.2] :
                   [0.2, 0.2, 0.6]; // maximize_satisfaction
    
    const normalizedCost = cost / constraints.maxBudget;
    const normalizedTime = time / constraints.maxTime;
    const normalizedSatisfaction = satisfaction / 1000;
    
    return weights[0] * (1 - normalizedCost) + 
           weights[1] * (1 - normalizedTime) + 
           weights[2] * normalizedSatisfaction;
  }

  private calculateDistance(source: any, destination: any): number {
    return Math.sqrt(
      Math.pow(source.lat - destination.lat, 2) + 
      Math.pow(source.lng - destination.lng, 2)
    ) * 111; // Convert to km
  }

  private tournamentSelection(population: Individual[], fitness: number[], count: number): Individual[] {
    const selected: Individual[] = [];
    
    for (let i = 0; i < count; i++) {
      const tournament = [];
      for (let j = 0; j < 3; j++) {
        const idx = Math.floor(Math.random() * population.length);
        tournament.push({ individual: population[idx], fitness: fitness[idx] });
      }
      
      tournament.sort((a, b) => b.fitness - a.fitness);
      selected.push(tournament[0].individual);
    }
    
    return selected;
  }

  private crossoverAndMutation(parents: Individual[], problem: OptimizationProblem): Individual[] {
    const offspring: Individual[] = [];
    
    for (let i = 0; i < parents.length - 1; i += 2) {
      const [child1, child2] = this.crossover(parents[i], parents[i + 1]);
      
      offspring.push(this.mutate(child1, problem));
      offspring.push(this.mutate(child2, problem));
    }
    
    return offspring;
  }

  private crossover(parent1: Individual, parent2: Individual): [Individual, Individual] {
    const crossoverPoint = Math.floor(Math.random() * Math.min(parent1.transfers.length, parent2.transfers.length));
    
    const child1: Individual = {
      transfers: [
        ...parent1.transfers.slice(0, crossoverPoint),
        ...parent2.transfers.slice(crossoverPoint)
      ],
      routes: [],
      allocations: {}
    };
    
    const child2: Individual = {
      transfers: [
        ...parent2.transfers.slice(0, crossoverPoint),
        ...parent1.transfers.slice(crossoverPoint)
      ],
      routes: [],
      allocations: {}
    };
    
    return [child1, child2];
  }

  private mutate(individual: Individual, problem: OptimizationProblem): Individual {
    const mutated = JSON.parse(JSON.stringify(individual));
    
    if (Math.random() < 0.1) { // 10% mutation rate
      if (mutated.transfers.length > 0) {
        const idx = Math.floor(Math.random() * mutated.transfers.length);
        mutated.transfers[idx].quantity = Math.floor(Math.random() * 100) + 10;
      }
    }
    
    return mutated;
  }

  private selectBest(population: Individual[], problem: OptimizationProblem, constraints: OptimizationConstraints, count: number): Individual[] {
    const fitness = population.map(individual => this.evaluateFitness(individual, problem, constraints));
    const indexed = population.map((individual, index) => ({ individual, fitness: fitness[index] }));
    
    indexed.sort((a, b) => b.fitness - a.fitness);
    
    return indexed.slice(0, count).map(item => item.individual);
  }

  private createOptimizationSolution(individual: Individual, problem: OptimizationProblem, constraints: OptimizationConstraints): OptimizationSolution {
    let totalCost = 0;
    let totalTime = 0;
    let customerSatisfaction = 0;
    
    individual.transfers.forEach(transfer => {
      const distance = this.calculateDistance(
        problem.sources[transfer.from],
        problem.destinations[transfer.to]
      );
      
      totalCost += distance * transfer.quantity * 0.5;
      totalTime += distance * 0.1 + transfer.quantity * 0.05;
      customerSatisfaction += transfer.quantity * 0.8;
    });
    
    return {
      transfers: individual.transfers,
      totalCost,
      totalTime,
      customerSatisfaction: Math.min(100, customerSatisfaction / 10),
      feasible: totalCost <= constraints.maxBudget && totalTime <= constraints.maxTime,
      efficiency: individual.transfers.length > 0 ? customerSatisfaction / totalCost : 0,
      environmentalImpact: totalCost * 0.1, // Simplified environmental calculation
      riskScore: Math.random() * 0.3 + 0.1 // Simplified risk calculation
    };
  }
}

// Advanced Prescriptive Optimizer
export class PrescriptiveOptimizer {
  private lpSolver: LinearProgrammingSolver;
  private heuristicOptimizer: HeuristicOptimizer;

  constructor() {
    this.lpSolver = new LinearProgrammingSolver();
    this.heuristicOptimizer = new HeuristicOptimizer();
  }

  /**
   * Generate optimized prescriptive actions based on current state and events
   */
  generateOptimizedActions(
    stores: Store[],
    distributionCenters: DistributionCenter[],
    activeEvent: Event | null,
    constraints: OptimizationConstraints
  ): Recommendation[] {
    const recommendations: Recommendation[] = [];
    
    // Identify critical situations
    const criticalStores = this.identifyCriticalStores(stores, activeEvent);
    
    if (criticalStores.length === 0) {
      return recommendations;
    }

    // Create optimization problem
    const problem = this.createOptimizationProblem(stores, distributionCenters, criticalStores, activeEvent);
    
    // Solve using appropriate method based on problem complexity
    let solution: OptimizationSolution;
    
    if (problem.sources.length * problem.destinations.length <= 100) {
      // Use linear programming for smaller problems
      const supply = problem.sources.map(s => s.availableStock);
      const demand = problem.destinations.map(d => d.requiredStock);
      const costs = this.calculateCostMatrix(problem.sources, problem.destinations);
      
      const lpSolution = this.lpSolver.solveTransportation(supply, demand, costs, constraints);
      solution = this.convertLPSolution(lpSolution, problem);
    } else {
      // Use heuristic optimization for larger problems
      solution = this.heuristicOptimizer.geneticAlgorithm(problem, constraints);
    }

    // Convert solution to recommendations
    recommendations.push(...this.convertSolutionToRecommendations(solution, problem, constraints));

    // Add event-specific recommendations
    if (activeEvent) {
      recommendations.push(...this.generateEventSpecificRecommendations(activeEvent, stores, constraints));
    }

    return recommendations;
  }

  private identifyCriticalStores(stores: Store[], activeEvent: Event | null): Store[] {
    return stores.filter(store => {
      const stockoutRisk = store.currentStock / (store.dailySalesAvg / 24);
      const eventMultiplier = activeEvent && activeEvent.region === store.region ? activeEvent.demandMultiplier : 1;
      const adjustedRisk = stockoutRisk / eventMultiplier;
      
      return adjustedRisk < 48 || store.currentStock < store.safetyStock * 0.5;
    });
  }

  private createOptimizationProblem(
    stores: Store[],
    distributionCenters: DistributionCenter[],
    criticalStores: Store[],
    activeEvent: Event | null
  ): OptimizationProblem {
    // Sources: stores with surplus + distribution centers
    const sources = [
      ...stores.filter(s => s.currentStock > s.safetyStock * 1.5).map(s => ({
        id: s.id,
        lat: s.lat,
        lng: s.lng,
        availableStock: s.currentStock - s.safetyStock * 1.2,
        type: 'store' as const
      })),
      ...distributionCenters.map(dc => ({
        id: dc.id,
        lat: dc.lat,
        lng: dc.lng,
        availableStock: Math.min(dc.currentStock, dc.throughputCapacity),
        type: 'dc' as const
      }))
    ];

    // Destinations: critical stores
    const destinations = criticalStores.map(s => ({
      id: s.id,
      lat: s.lat,
      lng: s.lng,
      requiredStock: Math.max(s.safetyStock * 1.5 - s.currentStock, s.dailySalesAvg * 2),
      priority: s.currentStock <= 0 ? 'critical' : s.currentStock < s.safetyStock * 0.5 ? 'high' : 'medium'
    }));

    return {
      sources,
      destinations,
      objective: activeEvent ? 'minimize_time' : 'minimize_cost',
      constraints: {
        maxBudget: 50000,
        maxTime: 48,
        minServiceLevel: 0.95
      }
    };
  }

  private calculateCostMatrix(sources: any[], destinations: any[]): number[][] {
    return sources.map(source => 
      destinations.map(dest => {
        const distance = this.calculateDistance(source, dest);
        const baseCost = distance * 0.5; // Base transport cost
        const urgencyMultiplier = dest.priority === 'critical' ? 0.8 : dest.priority === 'high' ? 0.9 : 1.0;
        const sourceMultiplier = source.type === 'dc' ? 0.7 : 1.0; // DCs are more efficient
        
        return baseCost * urgencyMultiplier * sourceMultiplier;
      })
    );
  }

  private calculateDistance(source: any, destination: any): number {
    return Math.sqrt(
      Math.pow(source.lat - destination.lat, 2) + 
      Math.pow(source.lng - destination.lng, 2)
    ) * 111; // Convert to km
  }

  private convertLPSolution(lpSolution: TransportationSolution, problem: OptimizationProblem): OptimizationSolution {
    const transfers: Transfer[] = [];
    
    lpSolution.allocation.forEach((row, i) => {
      row.forEach((quantity, j) => {
        if (quantity > 0) {
          transfers.push({
            from: i,
            to: j,
            quantity
          });
        }
      });
    });

    return {
      transfers,
      totalCost: lpSolution.totalCost,
      totalTime: lpSolution.totalTime,
      customerSatisfaction: 95, // Simplified
      feasible: lpSolution.feasible,
      efficiency: lpSolution.efficiency,
      environmentalImpact: lpSolution.totalCost * 0.1,
      riskScore: 0.15
    };
  }

  private convertSolutionToRecommendations(
    solution: OptimizationSolution,
    problem: OptimizationProblem,
    constraints: OptimizationConstraints
  ): Recommendation[] {
    return solution.transfers.map(transfer => {
      const source = problem.sources[transfer.from];
      const destination = problem.destinations[transfer.to];
      const distance = this.calculateDistance(source, destination);
      const estimatedCost = distance * transfer.quantity * 0.5;
      const estimatedTime = distance * 0.1 + transfer.quantity * 0.05;

      return {
        id: `OPT_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        type: 'transfer',
        productSku: 'AF-PRO-2025',
        quantity: transfer.quantity,
        origin: source.id,
        destination: destination.id,
        estimatedCost,
        estimatedTimeHours: estimatedTime,
        status: 'pending',
        reasoning: `Optimized transfer solution: Move ${transfer.quantity} units from ${source.id} to ${destination.id} to minimize ${problem.objective.replace('_', ' ')} while maintaining service levels.`,
        priority: destination.priority === 'critical' ? 'critical' : 'high',
        confidence: solution.feasible ? 0.92 : 0.75,
        expectedImpact: {
          stockoutPrevention: true,
          customerSatisfactionImprovement: solution.customerSatisfaction / 20,
          costSavings: estimatedCost * 0.15,
          revenueImpact: transfer.quantity * 59.99,
          operationalEfficiency: solution.efficiency * 10,
          environmentalBenefit: -solution.environmentalImpact,
          riskReduction: (1 - solution.riskScore) * 10
        },
        constraints: {
          maxCost: constraints.maxBudget,
          maxTime: constraints.maxTime,
          minQuantity: 5,
          requiredApproval: estimatedCost > 1000,
          sustainabilityRequirements: ['Carbon neutral transport', 'Minimal packaging']
        },
        alternatives: [],
        riskFactors: solution.riskScore > 0.3 ? ['High risk solution'] : [],
        successProbability: solution.feasible ? 0.95 : 0.70,
        createdAt: new Date(),
        mlModelUsed: 'Optimization Engine v2.1',
        dataQualityScore: 0.95,
        businessImpactScore: solution.efficiency,
        kpiImpact: {
          fillRate: 0.02,
          inventoryTurnover: 0.1,
          customerSatisfaction: solution.customerSatisfaction / 100,
          operationalCost: -estimatedCost
        }
      };
    });
  }

  private generateEventSpecificRecommendations(
    event: Event,
    stores: Store[],
    constraints: OptimizationConstraints
  ): Recommendation[] {
    const recommendations: Recommendation[] = [];

    switch (event.type) {
      case 'demand-surge':
        recommendations.push({
          id: `EVENT_${Date.now()}`,
          type: 'staff-allocation',
          productSku: 'Multiple',
          quantity: 20,
          origin: 'Regional_Pool',
          destination: event.region,
          estimatedCost: 3200,
          estimatedTimeHours: 4,
          status: 'pending',
          reasoning: `Demand surge optimization: Deploy additional staff to handle ${Math.round(event.demandMultiplier * 100)}% demand increase in ${event.region}.`,
          priority: 'critical',
          confidence: 0.88,
          expectedImpact: {
            stockoutPrevention: false,
            customerSatisfactionImprovement: 6.5,
            costSavings: 12000,
            revenueImpact: 0,
            operationalEfficiency: 25,
            environmentalBenefit: 0,
            riskReduction: 15
          },
          constraints: {
            maxCost: constraints.maxBudget,
            maxTime: 8,
            minQuantity: 15,
            requiredApproval: true,
            sustainabilityRequirements: []
          },
          alternatives: [
            {
              description: 'Overtime for existing staff',
              cost: 2400,
              time: 1,
              confidence: 0.75,
              environmentalImpact: 0
            }
          ],
          riskFactors: ['Staff availability', 'Training time'],
          successProbability: 0.85,
          createdAt: new Date(),
          mlModelUsed: 'Event Response Engine v1.5',
          dataQualityScore: 0.92,
          businessImpactScore: 0.88,
          kpiImpact: {
            fillRate: 0.05,
            inventoryTurnover: 0,
            customerSatisfaction: 0.065,
            operationalCost: 3200
          }
        });
        break;

      case 'road-closure':
        recommendations.push({
          id: `ROUTE_${Date.now()}`,
          type: 'reroute',
          productSku: 'Multiple',
          quantity: 0,
          origin: 'Affected_Routes',
          destination: 'Alternative_Routes',
          estimatedCost: 1800,
          estimatedTimeHours: 2,
          status: 'pending',
          reasoning: `Route optimization: Implement alternative routing to bypass road closure in ${event.region} and maintain delivery schedules.`,
          priority: 'high',
          confidence: 0.91,
          expectedImpact: {
            stockoutPrevention: false,
            customerSatisfactionImprovement: 4.2,
            costSavings: 6500,
            revenueImpact: 0,
            operationalEfficiency: 12,
            environmentalBenefit: -2.5,
            riskReduction: 20
          },
          constraints: {
            maxCost: constraints.maxBudget,
            maxTime: 4,
            minQuantity: 0,
            requiredApproval: false,
            sustainabilityRequirements: ['Fuel efficient routes']
          },
          alternatives: [
            {
              description: 'Delay deliveries until road reopens',
              cost: 0,
              time: 24,
              confidence: 0.95,
              environmentalImpact: 0
            }
          ],
          riskFactors: ['Alternative route capacity', 'Increased fuel consumption'],
          successProbability: 0.89,
          createdAt: new Date(),
          mlModelUsed: 'Route Optimization Engine v3.2',
          dataQualityScore: 0.94,
          businessImpactScore: 0.85,
          kpiImpact: {
            fillRate: 0.03,
            inventoryTurnover: 0,
            customerSatisfaction: 0.042,
            operationalCost: 1800
          }
        });
        break;
    }

    return recommendations;
  }
}

// Type definitions
export interface OptimizationConstraints {
  maxBudget: number;
  maxTime: number;
  minServiceLevel: number;
}

export interface OptimizationProblem {
  sources: Array<{
    id: string;
    lat: number;
    lng: number;
    availableStock: number;
    type: 'store' | 'dc';
  }>;
  destinations: Array<{
    id: string;
    lat: number;
    lng: number;
    requiredStock: number;
    priority: 'low' | 'medium' | 'high' | 'critical';
  }>;
  objective: 'minimize_cost' | 'minimize_time' | 'maximize_satisfaction';
  constraints: {
    maxBudget: number;
    maxTime: number;
    minServiceLevel: number;
  };
}

export interface Transfer {
  from: number;
  to: number;
  quantity: number;
}

export interface Individual {
  transfers: Transfer[];
  routes: any[];
  allocations: any;
}

export interface TransportationSolution {
  allocation: number[][];
  totalCost: number;
  totalTime: number;
  feasible: boolean;
  efficiency: number;
}

export interface OptimizationSolution {
  transfers: Transfer[];
  totalCost: number;
  totalTime: number;
  customerSatisfaction: number;
  feasible: boolean;
  efficiency: number;
  environmentalImpact: number;
  riskScore: number;
}

// Default optimizer instance
export const prescriptiveOptimizer = new PrescriptiveOptimizer();