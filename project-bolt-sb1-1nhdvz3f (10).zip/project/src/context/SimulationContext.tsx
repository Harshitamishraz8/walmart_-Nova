import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { generateMockData, aiModels, businessConstraints, marketConditions } from '../utils/mockData';
import { dataIntegrityEngine } from '../utils/dataIntegrity';
import { prescriptiveOptimizer } from '../utils/optimizer';
import type { Store, DistributionCenter, Recommendation, Event, Shipment, AIModel, DataQualityMetrics, PerformanceMetrics } from '../types';

interface SimulationState {
  stores: Store[];
  distributionCenters: DistributionCenter[];
  recommendations: Recommendation[];
  activeEvent: Event | null;
  shipments: Shipment[];
  simulationTime: number;
  isRunning: boolean;
  aiModels: AIModel[];
  dataQuality: DataQualityMetrics;
  performance: PerformanceMetrics;
  kpis: {
    stockoutsAverted: number;
    unitsTransferred: number;
    interventionCost: number;
    customerSatisfaction: number;
    operationalEfficiency: number;
    revenueProtected: number;
    costSavings: number;
  };
  dataAnomalyInjected: boolean;
  eventLog: Array<{ 
    timestamp: Date; 
    message: string; 
    type: 'info' | 'warning' | 'success' | 'error' | 'critical';
    category: 'system' | 'ai' | 'user' | 'external';
    impact: 'low' | 'medium' | 'high';
  }>;
  prescriptiveEngine: {
    isActive: boolean;
    confidence: number;
    lastAnalysis: Date | null;
    recommendationsGenerated: number;
    successRate: number;
    learningRate: number;
    modelVersion: string;
  };
  businessConstraints: typeof businessConstraints;
  marketConditions: typeof marketConditions;
}

type SimulationAction =
  | { type: 'START_SIMULATION' }
  | { type: 'PAUSE_SIMULATION' }
  | { type: 'RESET_SIMULATION' }
  | { type: 'ADVANCE_TIME' }
  | { type: 'SET_ACTIVE_EVENT'; payload: Event | null }
  | { type: 'ADD_RECOMMENDATION'; payload: Recommendation }
  | { type: 'EXECUTE_RECOMMENDATION'; payload: string }
  | { type: 'INJECT_ANOMALY' }
  | { type: 'CORRECT_ANOMALIES' }
  | { type: 'UPDATE_STORE_STOCK'; payload: { storeId: string; change: number } }
  | { type: 'ADD_SHIPMENT'; payload: Shipment }
  | { type: 'UPDATE_SHIPMENTS' }
  | { type: 'LOG_EVENT'; payload: { message: string; type: 'info' | 'warning' | 'success' | 'error' | 'critical'; category: 'system' | 'ai' | 'user' | 'external'; impact: 'low' | 'medium' | 'high' } }
  | { type: 'TRIGGER_PRESCRIPTIVE_ANALYSIS' }
  | { type: 'UPDATE_AI_CONFIDENCE'; payload: { modelType: string; confidence: number } }
  | { type: 'UPDATE_DATA_QUALITY'; payload: Partial<DataQualityMetrics> }
  | { type: 'UPDATE_PERFORMANCE'; payload: Partial<PerformanceMetrics> }
  | { type: 'APPLY_DATA_CORRECTIONS'; payload: { correctedStores: Store[]; correctedDCs: DistributionCenter[] } };

const initialState: SimulationState = {
  stores: [],
  distributionCenters: [],
  recommendations: [],
  activeEvent: null,
  shipments: [],
  simulationTime: 0,
  isRunning: false,
  aiModels: aiModels,
  dataQuality: {
    completeness: 0.98,
    accuracy: 0.95,
    consistency: 0.92,
    timeliness: 0.97,
    validity: 0.94,
    overall: 0.95,
  },
  performance: {
    stockoutRate: 0.02,
    fillRate: 0.98,
    inventoryTurnover: 12.5,
    customerSatisfaction: 0.94,
    operationalCost: 125000,
    responseTime: 2.3,
  },
  kpis: {
    stockoutsAverted: 0,
    unitsTransferred: 0,
    interventionCost: 0,
    customerSatisfaction: 94.2,
    operationalEfficiency: 92.8,
    revenueProtected: 0,
    costSavings: 0,
  },
  dataAnomalyInjected: false,
  eventLog: [],
  prescriptiveEngine: {
    isActive: true,
    confidence: 0.93,
    lastAnalysis: null,
    recommendationsGenerated: 0,
    successRate: 0.87,
    learningRate: 0.15,
    modelVersion: 'v2.3.1',
  },
  businessConstraints,
  marketConditions,
};

function simulationReducer(state: SimulationState, action: SimulationAction): SimulationState {
  switch (action.type) {
    case 'START_SIMULATION':
      return {
        ...state,
        isRunning: true,
        eventLog: [...state.eventLog, { 
          timestamp: new Date(), 
          message: 'AI Prescriptive Analytics Engine activated - Real-time optimization initiated', 
          type: 'success',
          category: 'system',
          impact: 'high'
        }],
      };

    case 'PAUSE_SIMULATION':
      return {
        ...state,
        isRunning: false,
        eventLog: [...state.eventLog, { 
          timestamp: new Date(), 
          message: 'Simulation paused - Analytics engine on standby', 
          type: 'info',
          category: 'user',
          impact: 'low'
        }],
      };

    case 'RESET_SIMULATION':
      const mockData = generateMockData();
      return {
        ...initialState,
        stores: mockData.stores,
        distributionCenters: mockData.distributionCenters,
        eventLog: [{ 
          timestamp: new Date(), 
          message: 'System initialized - AI Prescriptive Engine v2.3.1 ready for deployment', 
          type: 'success',
          category: 'system',
          impact: 'high'
        }],
      };

    case 'ADVANCE_TIME':
      const newTime = state.simulationTime + 1;
      
      // Apply data integrity validation and auto-correction
      const storeValidation = dataIntegrityEngine.validateAndCorrectData(state.stores, 'stores', true);
      const dcValidation = dataIntegrityEngine.validateAndCorrectData(state.distributionCenters, 'distribution_centers', true);
      
      let updatedStoresForTime = storeValidation.dataChanged ? storeValidation.correctedData : state.stores;
      let updatedDCsForTime = dcValidation.dataChanged ? dcValidation.correctedData : state.distributionCenters;
      
      // Apply sophisticated demand modeling
      updatedStoresForTime = updatedStoresForTime.map(store => {
        let demandMultiplier = 1.0;
        
        // Apply event impact
        if (state.activeEvent && state.activeEvent.region === store.region) {
          demandMultiplier = state.activeEvent.demandMultiplier;
        }
        
        // Apply seasonal and market factors
        demandMultiplier *= state.marketConditions.seasonalMultiplier;
        demandMultiplier *= state.marketConditions.competitorPressure;
        
        // Add realistic variability (±15%)
        const variability = 0.85 + Math.random() * 0.3;
        demandMultiplier *= variability;
        
        const hourlyDemand = (store.dailySalesAvg / 24) * demandMultiplier;
        const newStock = Math.max(0, store.currentStock - hourlyDemand);
        
        return {
          ...store,
          currentStock: newStock,
        };
      });

      // Log data corrections if any were applied
      const correctionLogs = [];
      if (storeValidation.dataChanged) {
        correctionLogs.push({ timestamp: new Date(), message: `Auto-corrected ${storeValidation.issues.filter(i => i.autoApplied).length} store data issues`, type: 'success' as const, category: 'ai' as const, impact: 'medium' as const });
      }
      if (dcValidation.dataChanged) {
        correctionLogs.push({ timestamp: new Date(), message: `Auto-corrected ${dcValidation.issues.filter(i => i.autoApplied).length} DC data issues`, type: 'success' as const, category: 'ai' as const, impact: 'medium' as const });
      }

      // Update AI model confidence based on performance
      const updatedAIModels = state.aiModels.map(model => ({
        ...model,
        confidence: Math.min(0.99, model.confidence + (Math.random() - 0.5) * 0.01),
      }));

      return {
        ...state,
        simulationTime: newTime,
        stores: updatedStoresForTime,
        distributionCenters: updatedDCsForTime,
        aiModels: updatedAIModels,
        eventLog: [...state.eventLog, ...correctionLogs, { 
          timestamp: new Date(), 
          message: `Hour ${newTime}: AI models processed ${updatedStoresForTime.length} locations, demand patterns analyzed`, 
          type: 'info',
          category: 'ai',
          impact: 'medium'
        }],
      };

    case 'SET_ACTIVE_EVENT':
      return {
        ...state,
        activeEvent: action.payload,
        eventLog: action.payload 
          ? [...state.eventLog, { 
              timestamp: new Date(), 
              message: `CRITICAL EVENT: ${action.payload.type} detected in ${action.payload.region} - AI analyzing optimal response strategies`, 
              type: 'critical',
              category: 'external',
              impact: 'high'
            }]
          : [...state.eventLog, { 
              timestamp: new Date(), 
              message: 'Event resolved - System returning to normal operations', 
              type: 'success',
              category: 'system',
              impact: 'medium'
            }],
      };

    case 'TRIGGER_PRESCRIPTIVE_ANALYSIS':
      // Use the advanced prescriptive optimizer
      const optimizedRecommendations = prescriptiveOptimizer.generateOptimizedActions(
        state.stores,
        state.distributionCenters,
        state.activeEvent,
        {
          maxBudget: state.businessConstraints.maxTransferCost * 20,
          maxTime: state.businessConstraints.maxTransferTime,
          minServiceLevel: state.businessConstraints.customerSatisfactionTarget
        }
      );
      const newRecommendations = [...generateAdvancedRecommendations(state), ...optimizedRecommendations];
      
      return {
        ...state,
        recommendations: [...state.recommendations, ...newRecommendations],
        prescriptiveEngine: {
          ...state.prescriptiveEngine,
          lastAnalysis: new Date(),
          recommendationsGenerated: state.prescriptiveEngine.recommendationsGenerated + newRecommendations.length,
          confidence: Math.min(0.99, state.prescriptiveEngine.confidence + 0.001),
        },
        eventLog: newRecommendations.length > 0 
          ? [...state.eventLog, {
              timestamp: new Date(), 
              message: `AI Engine generated ${newRecommendations.length} prescriptive recommendations with ${Math.round(state.prescriptiveEngine.confidence * 100)}% confidence`, 
              type: 'success',
              category: 'ai',
              impact: 'high'
            }]
          : state.eventLog,
      };

    case 'APPLY_DATA_CORRECTIONS':
      return {
        ...state,
        stores: action.payload.correctedStores,
        distributionCenters: action.payload.correctedDCs,
        eventLog: [...state.eventLog, {
          timestamp: new Date(),
          message: 'Manual data corrections applied - System data integrity restored',
          type: 'success',
          category: 'user',
          impact: 'high'
        }]
      };

    case 'EXECUTE_RECOMMENDATION':
      {
        const updatedRecs = state.recommendations.map(rec =>
        rec.id === action.payload ? { ...rec, status: 'executing' as const, executedAt: new Date() } : rec
      );
      
      const executedRec = updatedRecs.find(r => r.id === action.payload);
      
      if (!executedRec) return state;

      // Simulate execution effects
      let updatedKPIs = { ...state.kpis };
      let updatedStoresForExecution = [...state.stores];
      let updatedShipmentsForExecution = [...state.shipments];
      
      if (executedRec.type === 'transfer') {
        // Process transfer
        const sourceStore = updatedStoresForExecution.find(s => s.id === executedRec.origin);
        if (sourceStore && sourceStore.currentStock >= executedRec.quantity) {
          sourceStore.currentStock -= executedRec.quantity;
          
          // Add shipment
          updatedShipmentsForExecution.push({
            id: `SHIP_${Date.now()}`,
            productSku: executedRec.productSku,
            quantity: executedRec.quantity,
            origin: executedRec.origin,
            destination: executedRec.destination,
            etaHours: executedRec.estimatedTimeHours,
            type: 'transfer',
            priority: executedRec.priority === 'critical' ? 'urgent' : 'high',
            cost: executedRec.estimatedCost,
            route: [executedRec.origin, executedRec.destination],
            trackingStatus: 'dispatched',
          });

          updatedKPIs.unitsTransferred += executedRec.quantity;
          updatedKPIs.interventionCost += executedRec.estimatedCost;
          updatedKPIs.revenueProtected += executedRec.expectedImpact.revenueImpact;
          updatedKPIs.costSavings += executedRec.expectedImpact.costSavings;
        }
      }
      
      return {
        ...state,
        recommendations: updatedRecs,
        stores: updatedStoresForExecution,
        shipments: updatedShipmentsForExecution,
        kpis: updatedKPIs,
        prescriptiveEngine: {
          ...state.prescriptiveEngine,
          successRate: Math.min(0.99, state.prescriptiveEngine.successRate + 0.01),
        },
        eventLog: [...state.eventLog, { 
          timestamp: new Date(), 
          message: `EXECUTING: ${executedRec.type} recommendation - ${executedRec.quantity} units from ${executedRec.origin} to ${executedRec.destination}`, 
          type: 'success',
          category: 'ai',
          impact: 'high'
        }],
      };
      }

    case 'UPDATE_SHIPMENTS':
      {
        const processedShipmentsForUpdate = state.shipments.map(shipment => ({
        ...shipment,
        etaHours: Math.max(0, shipment.etaHours - 1),
        trackingStatus: shipment.etaHours <= 1 ? 'delivered' as const : shipment.trackingStatus,
      }));

      const arrivedShipments = processedShipmentsForUpdate.filter(s => s.etaHours === 0 && s.trackingStatus === 'delivered');
      const remainingShipments = processedShipmentsForUpdate.filter(s => s.etaHours > 0 || s.trackingStatus !== 'delivered');

      let updatedStoresForShipmentUpdate = [...state.stores];
      let stockoutsAverted = state.kpis.stockoutsAverted;
      
      arrivedShipments.forEach(shipment => {
        const targetStore = updatedStoresForShipmentUpdate.find(s => s.id === shipment.destination);
        if (targetStore) {
          const wasLowStock = targetStore.currentStock < targetStore.safetyStock;
          targetStore.currentStock += shipment.quantity;
          if (wasLowStock && targetStore.currentStock >= targetStore.safetyStock) {
            stockoutsAverted += 1;
          }
        }
      });

      return {
        ...state,
        shipments: remainingShipments,
        stores: updatedStoresForShipmentUpdate,
        kpis: {
          ...state.kpis,
          stockoutsAverted,
          customerSatisfaction: arrivedShipments.length > 0 
            ? Math.min(100, state.kpis.customerSatisfaction + 0.1) 
            : state.kpis.customerSatisfaction,
        },
        eventLog: arrivedShipments.length > 0 
          ? [...state.eventLog, ...arrivedShipments.map(s => ({ 
              timestamp: new Date(), 
              message: `DELIVERY COMPLETE: ${s.quantity} units arrived at ${s.destination} - Inventory optimized`, 
              type: 'success' as const,
              category: 'system' as const,
              impact: 'medium' as const
            }))]
          : state.eventLog,
      };
      }

    case 'INJECT_ANOMALY':
      const randomStore = state.stores[Math.floor(Math.random() * state.stores.length)];
      const updatedStoresWithAnomaly = state.stores.map(store =>
        store.id === randomStore.id ? { ...store, currentStock: -Math.abs(store.currentStock) - 50 } : store
      );

      return {
        ...state,
        stores: updatedStoresWithAnomaly,
        dataAnomalyInjected: true,
        dataQuality: {
          ...state.dataQuality,
          accuracy: Math.max(0.5, state.dataQuality.accuracy - 0.15),
          overall: Math.max(0.5, state.dataQuality.overall - 0.1),
        },
        eventLog: [...state.eventLog, { 
          timestamp: new Date(), 
          message: `DATA ANOMALY DETECTED: Negative inventory at ${randomStore.id} - AI validation required`, 
          type: 'error',
          category: 'system',
          impact: 'high'
        }],
      };

    case 'CORRECT_ANOMALIES':
      const correctedStores = state.stores.map(store =>
        store.currentStock < 0 ? { ...store, currentStock: Math.max(0, store.dailySalesAvg * 2) } : store
      );

      return {
        ...state,
        stores: correctedStores,
        dataAnomalyInjected: false,
        dataQuality: {
          ...state.dataQuality,
          accuracy: Math.min(0.99, state.dataQuality.accuracy + 0.1),
          overall: Math.min(0.99, state.dataQuality.overall + 0.08),
        },
        eventLog: [...state.eventLog, { 
          timestamp: new Date(), 
          message: 'AI Data Validation Complete: Anomalies corrected using predictive models and historical patterns', 
          type: 'success',
          category: 'ai',
          impact: 'high'
        }],
      };

    default:
      return state;
  }
}

// Enhanced recommendation generation with realistic business logic
function generateAdvancedRecommendations(state: SimulationState): Recommendation[] {
  const recommendations: Recommendation[] = [];
  
  // Analyze critical stock situations with sophisticated logic
  const criticalStores = state.stores.filter(store => {
    const stockoutRisk = store.currentStock / (store.dailySalesAvg / 24); // Hours until stockout
    const isCritical = stockoutRisk < 24 || store.currentStock < store.safetyStock * 0.5;
    return isCritical;
  });

  criticalStores.forEach(criticalStore => {
    const urgencyScore = calculateUrgencyScore(criticalStore, state);
    const potentialSources = findOptimalSources(criticalStore, state);
    
    if (potentialSources.length > 0) {
      const bestSource = potentialSources[0];
      const transferQuantity = calculateOptimalTransferQuantity(criticalStore, bestSource, state);
      
      if (transferQuantity > 0) {
        const recommendation = createTransferRecommendation(
          criticalStore, 
          bestSource, 
          transferQuantity, 
          urgencyScore,
          state
        );
        recommendations.push(recommendation);
      }
    } else {
      // No internal sources available, recommend supplier order
      const supplierRec = createSupplierOrderRecommendation(criticalStore, urgencyScore, state);
      if (supplierRec) {
        recommendations.push(supplierRec);
      }
    }
  });

  // Event-specific recommendations
  if (state.activeEvent) {
    const eventRecs = generateEventSpecificRecommendations(state.activeEvent, state);
    recommendations.push(...eventRecs);
  }

  // Proactive optimization recommendations
  const optimizationRecs = generateOptimizationRecommendations(state);
  recommendations.push(...optimizationRecs);

  return recommendations;
}

function calculateUrgencyScore(store: Store, state: SimulationState): number {
  const hoursUntilStockout = store.currentStock / (store.dailySalesAvg / 24);
  const safetyStockRatio = store.currentStock / store.safetyStock;
  const demandTrend = state.activeEvent ? state.activeEvent.demandMultiplier : 1.0;
  
  let urgency = 0;
  if (hoursUntilStockout < 12) urgency += 0.4;
  else if (hoursUntilStockout < 24) urgency += 0.3;
  else if (hoursUntilStockout < 48) urgency += 0.2;
  
  if (safetyStockRatio < 0.5) urgency += 0.3;
  else if (safetyStockRatio < 1.0) urgency += 0.2;
  
  if (demandTrend > 1.5) urgency += 0.2;
  else if (demandTrend > 1.2) urgency += 0.1;
  
  return Math.min(1.0, urgency);
}

function findOptimalSources(targetStore: Store, state: SimulationState): Store[] {
  return state.stores
    .filter(store => 
      store.id !== targetStore.id && 
      store.region !== targetStore.region &&
      store.currentStock > store.safetyStock * 1.5 &&
      store.operationalStatus === 'operational'
    )
    .map(store => ({
      ...store,
      transferScore: calculateTransferScore(store, targetStore, state)
    }))
    .sort((a, b) => b.transferScore - a.transferScore);
}

function calculateTransferScore(source: Store, target: Store, state: SimulationState): number {
  const distance = Math.sqrt(
    Math.pow(source.lat - target.lat, 2) + Math.pow(source.lng - target.lng, 2)
  );
  const availableStock = source.currentStock - source.safetyStock;
  const transferCost = distance * state.marketConditions.transportationCosts.regional;
  
  return (availableStock * 0.4) - (transferCost * 0.3) - (distance * 0.3);
}

function calculateOptimalTransferQuantity(target: Store, source: Store, state: SimulationState): number {
  const targetNeed = target.safetyStock * 1.5 - target.currentStock;
  const sourceAvailable = source.currentStock - source.safetyStock * 1.2;
  const maxTransfer = Math.min(targetNeed, sourceAvailable);
  
  return Math.max(0, Math.floor(maxTransfer));
}

function createTransferRecommendation(
  target: Store, 
  source: Store, 
  quantity: number, 
  urgency: number,
  state: SimulationState
): Recommendation {
  const distance = Math.sqrt(
    Math.pow(source.lat - target.lat, 2) + Math.pow(source.lng - target.lng, 2)
  );
  const estimatedCost = quantity * distance * state.marketConditions.transportationCosts.regional;
  const estimatedTime = Math.max(4, distance * 2); // Minimum 4 hours
  
  const priority = urgency > 0.7 ? 'critical' : urgency > 0.5 ? 'high' : 'medium';
  const confidence = Math.min(0.95, 0.7 + (urgency * 0.25));
  
  return {
    id: `REC_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    type: 'transfer',
    productSku: 'AF-PRO-2025',
    quantity,
    origin: source.id,
    destination: target.id,
    estimatedCost,
    estimatedTimeHours: estimatedTime,
    status: 'pending',
    reasoning: `Critical stock situation at ${target.id} (${Math.round(target.currentStock)} units remaining). Transfer from ${source.id} with surplus inventory to prevent stockout and maintain customer satisfaction. Urgency score: ${Math.round(urgency * 100)}%`,
    priority,
    confidence,
    expectedImpact: {
      stockoutPrevention: true,
      customerSatisfactionImprovement: urgency * 5,
      costSavings: quantity * 15, // Avoid lost sales
      revenueImpact: quantity * 59.99, // Product price
      operationalEfficiency: 2.5,
    },
    constraints: {
      maxCost: state.businessConstraints.maxTransferCost,
      maxTime: state.businessConstraints.maxTransferTime,
      minQuantity: state.businessConstraints.minTransferQuantity,
      requiredApproval: estimatedCost > 500,
    },
    alternatives: [
      {
        description: 'Expedited supplier order',
        cost: quantity * 45,
        time: 48,
        confidence: 0.85,
      },
      {
        description: 'Customer backorder with discount',
        cost: quantity * 5,
        time: 72,
        confidence: 0.60,
      },
    ],
    riskFactors: [
      distance > 500 ? 'Long distance transfer' : '',
      source.currentStock < source.safetyStock * 2 ? 'Source store low inventory' : '',
      estimatedTime > 24 ? 'Extended delivery time' : '',
    ].filter(Boolean),
    successProbability: Math.min(0.95, confidence + 0.1),
    createdAt: new Date(),
  };
}

function createSupplierOrderRecommendation(store: Store, urgency: number, state: SimulationState): Recommendation | null {
  const orderQuantity = Math.max(store.safetyStock * 2, store.dailySalesAvg * 3);
  const isExpedited = urgency > 0.6;
  const baseCost = 45; // Base supplier cost
  const expeditedMultiplier = isExpedited ? 1.5 : 1.0;
  const estimatedCost = orderQuantity * baseCost * expeditedMultiplier;
  const estimatedTime = isExpedited ? 24 : 48;
  
  return {
    id: `SUP_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    type: 'supplier-order',
    productSku: 'AF-PRO-2025',
    quantity: orderQuantity,
    origin: 'Supplier_Premium',
    destination: store.region.includes('A') || store.region.includes('B') ? 'DC_East' : 'DC_West',
    estimatedCost,
    estimatedTimeHours: estimatedTime,
    status: 'pending',
    reasoning: `No suitable internal transfer sources available for ${store.id}. ${isExpedited ? 'Expedited' : 'Standard'} supplier order required to replenish regional inventory and prevent stockout.`,
    priority: urgency > 0.7 ? 'critical' : 'high',
    confidence: 0.88,
    expectedImpact: {
      stockoutPrevention: true,
      customerSatisfactionImprovement: urgency * 3,
      costSavings: 0,
      revenueImpact: orderQuantity * 59.99,
      operationalEfficiency: 1.5,
    },
    constraints: {
      maxCost: state.businessConstraints.maxTransferCost * 2,
      maxTime: 72,
      minQuantity: store.dailySalesAvg,
      requiredApproval: true,
    },
    alternatives: [],
    riskFactors: [
      'Supplier dependency',
      isExpedited ? 'Premium pricing' : 'Standard lead time',
    ],
    successProbability: 0.92,
    createdAt: new Date(),
  };
}

function generateEventSpecificRecommendations(event: Event, state: SimulationState): Recommendation[] {
  const recommendations: Recommendation[] = [];
  
  switch (event.type) {
    case 'demand-surge':
      // Staff allocation recommendation
      recommendations.push({
        id: `STAFF_${Date.now()}`,
        type: 'staff-allocation',
        productSku: 'Multiple',
        quantity: 15,
        origin: 'Regional_Pool',
        destination: event.region,
        estimatedCost: 2400,
        estimatedTimeHours: 2,
        status: 'pending',
        reasoning: `Demand surge detected in ${event.region}. Deploy additional fulfillment staff to handle ${Math.round(event.demandMultiplier * 100)}% increase in order volume.`,
        priority: 'high',
        confidence: 0.91,
        expectedImpact: {
          stockoutPrevention: false,
          customerSatisfactionImprovement: 4.2,
          costSavings: 8500,
          revenueImpact: 0,
          operationalEfficiency: 15,
        },
        constraints: {
          maxCost: 5000,
          maxTime: 4,
          minQuantity: 10,
          requiredApproval: false,
        },
        alternatives: [],
        riskFactors: ['Staff availability', 'Training requirements'],
        successProbability: 0.89,
        createdAt: new Date(),
      });
      break;
      
    case 'road-closure':
      // Route optimization recommendation
      recommendations.push({
        id: `ROUTE_${Date.now()}`,
        type: 'reroute',
        productSku: 'Multiple',
        quantity: 0,
        origin: 'Current_Routes',
        destination: 'Alternative_Routes',
        estimatedCost: 1200,
        estimatedTimeHours: 1,
        status: 'pending',
        reasoning: `Road closure affecting delivery routes in ${event.region}. Implement alternative routing to maintain delivery schedules.`,
        priority: 'high',
        confidence: 0.94,
        expectedImpact: {
          stockoutPrevention: false,
          customerSatisfactionImprovement: 3.1,
          costSavings: 4500,
          revenueImpact: 0,
          operationalEfficiency: 8,
        },
        constraints: {
          maxCost: 2000,
          maxTime: 2,
          minQuantity: 0,
          requiredApproval: false,
        },
        alternatives: [],
        riskFactors: ['Route availability', 'Increased fuel costs'],
        successProbability: 0.92,
        createdAt: new Date(),
      });
      break;
  }
  
  return recommendations;
}

function generateOptimizationRecommendations(state: SimulationState): Recommendation[] {
  const recommendations: Recommendation[] = [];
  
  // Price adjustment for slow-moving inventory
  const overstockedStores = state.stores.filter(store => 
    store.currentStock > store.safetyStock * 2.5
  );
  
  if (overstockedStores.length > 0) {
    const store = overstockedStores[0];
    recommendations.push({
      id: `PRICE_${Date.now()}`,
      type: 'price-adjustment',
      productSku: 'AF-PRO-2025',
      quantity: Math.floor(store.currentStock - store.safetyStock * 2),
      origin: store.id,
      destination: 'Market',
      estimatedCost: 0,
      estimatedTimeHours: 1,
      status: 'pending',
      reasoning: `Excess inventory at ${store.id}. Recommend 15% price reduction to accelerate sales and optimize inventory turnover.`,
      priority: 'medium',
      confidence: 0.82,
      expectedImpact: {
        stockoutPrevention: false,
        customerSatisfactionImprovement: 1.5,
        costSavings: 2500,
        revenueImpact: -1500, // Revenue reduction due to discount
        operationalEfficiency: 5,
      },
      constraints: {
        maxCost: 0,
        maxTime: 24,
        minQuantity: 10,
        requiredApproval: true,
      },
      alternatives: [
        {
          description: 'Transfer to high-demand location',
          cost: 800,
          time: 24,
          confidence: 0.75,
        },
      ],
      riskFactors: ['Brand perception', 'Margin impact'],
      successProbability: 0.78,
      createdAt: new Date(),
    });
  }
  
  return recommendations;
}

const SimulationContext = createContext<{
  state: SimulationState;
  dispatch: React.Dispatch<SimulationAction>;
} | null>(null);

export function SimulationProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(simulationReducer, initialState);

  // Initialize data on mount
  useEffect(() => {
    dispatch({ type: 'RESET_SIMULATION' });
  }, []);

  // Enhanced simulation loop with realistic timing
  useEffect(() => {
    if (!state.isRunning) return;

    const interval = setInterval(() => {
      dispatch({ type: 'ADVANCE_TIME' });
      dispatch({ type: 'UPDATE_SHIPMENTS' });
      
      // Trigger prescriptive analysis every 3 hours or when events occur
      if (state.simulationTime % 3 === 0 || state.activeEvent) {
        dispatch({ type: 'TRIGGER_PRESCRIPTIVE_ANALYSIS' });
      }
      
      // Update data quality metrics periodically
      if (state.simulationTime % 6 === 0) {
        dispatch({ 
          type: 'UPDATE_DATA_QUALITY', 
          payload: {
            timeliness: Math.min(0.99, state.dataQuality.timeliness + (Math.random() - 0.5) * 0.02)
          }
        });
      }
    }, 2000); // 2 second intervals for demo

    return () => clearInterval(interval);
  }, [state.isRunning, state.simulationTime, state.activeEvent]);

  return (
    <SimulationContext.Provider value={{ state, dispatch }}>
      {children}
    </SimulationContext.Provider>
  );
}

export function useSimulation() {
  const context = useContext(SimulationContext);
  if (!context) {
    throw new Error('useSimulation must be used within a SimulationProvider');
  }
  return context;
}