import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { Calendar, AlertTriangle, TrendingUp, Clock, MapPin, Users } from 'lucide-react';

const EventSimulation: React.FC = () => {
  const { state, dispatch } = useSimulation();

  const eventTypes = [
    {
      id: 'demand-surge',
      name: 'Demand Surge',
      description: 'Sudden 300% increase in product demand',
      region: 'Region A',
      severity: 'critical',
      probability: 0.85,
      icon: TrendingUp,
      color: 'bg-red-500'
    },
    {
      id: 'weather-alert',
      name: 'Severe Weather Alert',
      description: 'Heavy storms affecting logistics routes',
      region: 'Region B',
      severity: 'high',
      probability: 0.72,
      icon: AlertTriangle,
      color: 'bg-orange-500'
    },
    {
      id: 'supplier-delay',
      name: 'Supplier Delay',
      description: 'Manufacturing delay at primary supplier',
      region: 'All Regions',
      severity: 'medium',
      probability: 0.45,
      icon: Clock,
      color: 'bg-yellow-500'
    },
    {
      id: 'road-closure',
      name: 'Major Road Closure',
      description: 'Highway closure affecting delivery routes',
      region: 'Region C',
      severity: 'high',
      probability: 0.60,
      icon: MapPin,
      color: 'bg-purple-500'
    },
    {
      id: 'labor-shortage',
      name: 'Labor Shortage',
      description: 'Staffing shortage at distribution center',
      region: 'Region A',
      severity: 'medium',
      probability: 0.38,
      icon: Users,
      color: 'bg-blue-500'
    }
  ];

  const handleTriggerEvent = (eventType: any) => {
    const event = {
      id: `event_${Date.now()}`,
      type: eventType.id,
      name: eventType.name,
      description: eventType.description,
      region: eventType.region,
      severity: eventType.severity,
      demandMultiplier: eventType.id === 'demand-surge' ? 3.0 : 
                       eventType.id === 'weather-alert' ? 1.5 : 1.0,
      startTime: new Date(),
      duration: 24, // hours
      isActive: true
    };

    dispatch({ type: 'SET_ACTIVE_EVENT', payload: event });
  };

  const handleClearEvent = () => {
    dispatch({ type: 'SET_ACTIVE_EVENT', payload: null });
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Event Simulation</h2>
        
        {state.activeEvent && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-red-800">
                  Active Event: {state.activeEvent.name}
                </h3>
                <p className="text-red-600">{state.activeEvent.description}</p>
                <p className="text-sm text-red-500 mt-1">
                  Region: {state.activeEvent.region} | Severity: {state.activeEvent.severity}
                </p>
              </div>
              <button
                onClick={handleClearEvent}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                Clear Event
              </button>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {eventTypes.map((eventType) => {
            const IconComponent = eventType.icon;
            return (
              <div
                key={eventType.id}
                className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg p-4 border border-gray-200 hover:shadow-md transition-all duration-200"
              >
                <div className="flex items-start space-x-3">
                  <div className={`${eventType.color} p-2 rounded-lg`}>
                    <IconComponent className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">{eventType.name}</h3>
                    <p className="text-sm text-gray-600 mt-1">{eventType.description}</p>
                    <div className="mt-2 space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-500">Region:</span>
                        <span className="font-medium">{eventType.region}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-500">Severity:</span>
                        <span className={`font-medium ${
                          eventType.severity === 'critical' ? 'text-red-600' :
                          eventType.severity === 'high' ? 'text-orange-600' :
                          'text-yellow-600'
                        }`}>
                          {eventType.severity}
                        </span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-500">Probability:</span>
                        <span className="font-medium">{(eventType.probability * 100).toFixed(0)}%</span>
                      </div>
                    </div>
                    <button
                      onClick={() => handleTriggerEvent(eventType)}
                      disabled={state.activeEvent?.type === eventType.id}
                      className="mt-3 w-full px-3 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
                    >
                      {state.activeEvent?.type === eventType.id ? 'Active' : 'Trigger Event'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Simulation Controls</h3>
        <div className="flex space-x-4">
          <button
            onClick={() => dispatch({ type: state.isRunning ? 'PAUSE_SIMULATION' : 'START_SIMULATION' })}
            className={`px-6 py-3 rounded-lg font-medium transition-colors ${
              state.isRunning
                ? 'bg-red-600 hover:bg-red-700 text-white'
                : 'bg-green-600 hover:bg-green-700 text-white'
            }`}
          >
            {state.isRunning ? 'Pause Simulation' : 'Start Simulation'}
          </button>
          <button
            onClick={() => dispatch({ type: 'RESET_SIMULATION' })}
            className="px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white rounded-lg font-medium transition-colors"
          >
            Reset Simulation
          </button>
        </div>
        
        <div className="mt-4">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Simulation Time</span>
            <span>Hour {state.simulationTime} / 168</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(state.simulationTime / 168) * 100}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default EventSimulation;

export { EventSimulation }