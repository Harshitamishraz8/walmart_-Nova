import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { KPICards } from './dashboard/KPICards';
import { SupplyChainMap } from './dashboard/SupplyChainMap';
import { StockCharts } from './dashboard/StockCharts';
import { AlertsPanel } from './dashboard/AlertsPanel';
import { SimulationControls } from './dashboard/SimulationControls';
import { Brain, Zap, TrendingUp, Shield, BarChart3, Users } from 'lucide-react';

export function Dashboard() {
  const { state } = useSimulation();

  const criticalStores = state.stores.filter(store => 
    store.currentStock < store.safetyStock * 0.5 || 
    (store.currentStock / (store.dailySalesAvg / 24)) < 24
  );

  const aiModelsActive = state.aiModels.filter(model => model.status === 'active').length;
  const avgModelAccuracy = state.aiModels.reduce((sum, model) => sum + model.accuracy, 0) / state.aiModels.length;

  return (
    <div className="p-6 space-y-6">
      {/* Enhanced Header */}
      <div className="bg-gradient-to-r from-white via-blue-50 to-walmart-blue/10 rounded-2xl shadow-xl border border-blue-200 p-8">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-4 mb-3">
              <div className="p-4 bg-gradient-to-br from-walmart-blue to-blue-600 rounded-xl shadow-lg">
                <Brain className="w-10 h-10 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-walmart-blue to-blue-600 bg-clip-text text-transparent">
                  Supply Chain Command Center
                </h1>
                <p className="text-gray-600 mt-1 text-lg">AI-Powered Prescriptive Analytics for Smart Air Fryer Pro</p>
              </div>
            </div>
            <div className="flex items-center space-x-6 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-green-600 font-medium">{aiModelsActive} AI Models Active</span>
              </div>
              <div className="flex items-center space-x-2">
                <Zap className="w-4 h-4 text-blue-500" />
                <span className="text-gray-600">Model Accuracy: {Math.round(avgModelAccuracy * 100)}%</span>
              </div>
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-green-500" />
                <span className="text-gray-600">Data Quality: {Math.round(state.dataQuality.overall * 100)}%</span>
              </div>
              <div className="flex items-center space-x-2">
                <Shield className="w-4 h-4 text-purple-500" />
                <span className="text-gray-600">Engine Confidence: {Math.round(state.prescriptiveEngine.confidence * 100)}%</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="bg-white/90 rounded-xl p-6 shadow-lg border border-blue-200">
              <p className="text-sm text-gray-500 mb-1">Simulation Time</p>
              <p className="text-3xl font-bold text-walmart-blue">{state.simulationTime}h</p>
              <div className="flex items-center justify-end mt-2">
                <div className={`w-3 h-3 rounded-full mr-2 ${state.isRunning ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}></div>
                <span className="text-xs text-gray-600">
                  {state.isRunning ? 'Running' : 'Paused'}
                </span>
              </div>
              <div className="mt-3 text-xs text-gray-500">
                <div className="flex justify-between">
                  <span>Active Events:</span>
                  <span className="font-medium">{state.activeEvent ? 1 : 0}</span>
                </div>
                <div className="flex justify-between">
                  <span>Critical Stores:</span>
                  <span className={`font-medium ${criticalStores.length > 0 ? 'text-red-600' : 'text-green-600'}`}>
                    {criticalStores.length}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced KPI Cards */}
      <KPICards />

      {/* AI Models Status */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900 flex items-center">
            <BarChart3 className="w-5 h-5 mr-2 text-walmart-blue" />
            AI Models Performance
          </h2>
          <div className="text-sm text-gray-500">
            Last Updated: {new Date().toLocaleTimeString()}
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {state.aiModels.map((model, index) => (
            <div key={index} className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4 border border-blue-200">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium text-blue-900 text-sm">{model.name}</h3>
                <div className={`w-2 h-2 rounded-full ${
                  model.status === 'active' ? 'bg-green-500' : 
                  model.status === 'training' ? 'bg-yellow-500' : 'bg-red-500'
                }`}></div>
              </div>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <span className="text-blue-700">Accuracy:</span>
                  <span className="font-medium text-blue-900">{Math.round(model.accuracy * 100)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-blue-700">Confidence:</span>
                  <span className="font-medium text-blue-900">{Math.round(model.confidence * 100)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-blue-700">Status:</span>
                  <span className={`font-medium capitalize ${
                    model.status === 'active' ? 'text-green-600' : 
                    model.status === 'training' ? 'text-yellow-600' : 'text-red-600'
                  }`}>{model.status}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Supply Chain Map */}
        <div className="xl:col-span-2">
          <SupplyChainMap />
        </div>

        {/* Controls and Alerts */}
        <div className="space-y-6">
          <SimulationControls />
          <AlertsPanel />
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900 flex items-center">
            <Users className="w-5 h-5 mr-2 text-walmart-blue" />
            Business Performance Metrics
          </h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4 border border-green-200">
            <h3 className="font-medium text-green-900 text-sm mb-2">Fill Rate</h3>
            <p className="text-2xl font-bold text-green-700">{Math.round(state.performance.fillRate * 100)}%</p>
            <p className="text-xs text-green-600 mt-1">Target: 98%</p>
          </div>
          
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4 border border-blue-200">
            <h3 className="font-medium text-blue-900 text-sm mb-2">Inventory Turnover</h3>
            <p className="text-2xl font-bold text-blue-700">{state.performance.inventoryTurnover.toFixed(1)}</p>
            <p className="text-xs text-blue-600 mt-1">Annual rate</p>
          </div>
          
          <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4 border border-purple-200">
            <h3 className="font-medium text-purple-900 text-sm mb-2">Customer Satisfaction</h3>
            <p className="text-2xl font-bold text-purple-700">{Math.round(state.performance.customerSatisfaction * 100)}%</p>
            <p className="text-xs text-purple-600 mt-1">Current score</p>
          </div>
          
          <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-lg p-4 border border-red-200">
            <h3 className="font-medium text-red-900 text-sm mb-2">Stockout Rate</h3>
            <p className="text-2xl font-bold text-red-700">{Math.round(state.performance.stockoutRate * 100)}%</p>
            <p className="text-xs text-red-600 mt-1">Monthly average</p>
          </div>
          
          <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg p-4 border border-yellow-200">
            <h3 className="font-medium text-yellow-900 text-sm mb-2">Response Time</h3>
            <p className="text-2xl font-bold text-yellow-700">{state.performance.responseTime.toFixed(1)}h</p>
            <p className="text-xs text-yellow-600 mt-1">Avg resolution</p>
          </div>
          
          <div className="bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-lg p-4 border border-indigo-200">
            <h3 className="font-medium text-indigo-900 text-sm mb-2">Operational Cost</h3>
            <p className="text-2xl font-bold text-indigo-700">${(state.performance.operationalCost / 1000).toFixed(0)}K</p>
            <p className="text-xs text-indigo-600 mt-1">Monthly</p>
          </div>
        </div>
      </div>

      {/* Stock Charts */}
      <StockCharts />
    </div>
  );
}