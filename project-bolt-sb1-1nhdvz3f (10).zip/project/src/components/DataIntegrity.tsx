import React, { useState, useEffect } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { dataIntegrityEngine, type DataIssue, type DataQualityReport } from '../utils/dataIntegrity';
import { Shield, AlertTriangle, CheckCircle, Bug, Sparkles, TrendingUp, Database, Zap, Settings, Play, Pause } from 'lucide-react';

export function DataIntegrity() {
  const { state, dispatch } = useSimulation();
  const [dataIssues, setDataIssues] = useState<DataIssue[]>([]);
  const [qualityReport, setQualityReport] = useState<DataQualityReport | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedSeverity, setSelectedSeverity] = useState<string>('all');
  const [autoCorrectEnabled, setAutoCorrectEnabled] = useState(true);
  const [realTimeMonitoring, setRealTimeMonitoring] = useState(true);

  useEffect(() => {
    // Run initial data analysis
    runDataAnalysis();
  }, [state.stores, state.distributionCenters]);

  useEffect(() => {
    // Real-time monitoring
    if (realTimeMonitoring && state.isRunning) {
      const interval = setInterval(() => {
        runDataAnalysis(false); // Silent analysis
      }, 5000);
      
      return () => clearInterval(interval);
    }
  }, [realTimeMonitoring, state.isRunning]);

  const runDataAnalysis = async (showLoading = true) => {
    if (showLoading) setIsAnalyzing(true);
    
    try {
      // Simulate AI analysis delay for demo
      if (showLoading) {
        await new Promise(resolve => setTimeout(resolve, 1500));
      }
      
      // Analyze stores data with auto-correction
      const storesAnalysis = dataIntegrityEngine.validateAndCorrectData(
        state.stores, 
        'stores', 
        autoCorrectEnabled
      );
      
      // Analyze distribution centers data with auto-correction
      const dcsAnalysis = dataIntegrityEngine.validateAndCorrectData(
        state.distributionCenters, 
        'distribution_centers', 
        autoCorrectEnabled
      );
      
      // Apply corrections if data was changed
      if (storesAnalysis.dataChanged || dcsAnalysis.dataChanged) {
        dispatch({
          type: 'APPLY_DATA_CORRECTIONS',
          payload: {
            correctedStores: storesAnalysis.correctedData,
            correctedDCs: dcsAnalysis.correctedData
          }
        });
      }
      
      // Combine results
      const allIssues = [...storesAnalysis.issues, ...dcsAnalysis.issues];
      const combinedReport: DataQualityReport = {
        totalRecords: storesAnalysis.report.totalRecords + dcsAnalysis.report.totalRecords,
        issuesFound: storesAnalysis.report.issuesFound + dcsAnalysis.report.issuesFound,
        issuesCorrected: storesAnalysis.report.issuesCorrected + dcsAnalysis.report.issuesCorrected,
        autoCorrectionsApplied: storesAnalysis.report.autoCorrectionsApplied + dcsAnalysis.report.autoCorrectionsApplied,
        qualityScore: (storesAnalysis.report.qualityScore + dcsAnalysis.report.qualityScore) / 2,
        categories: { ...storesAnalysis.report.categories, ...dcsAnalysis.report.categories },
        trends: storesAnalysis.report.trends,
        recommendations: [...storesAnalysis.report.recommendations, ...dcsAnalysis.report.recommendations]
      };
      
      setDataIssues(allIssues);
      setQualityReport(combinedReport);
      
      // Update global data quality in context
      dispatch({
        type: 'UPDATE_DATA_QUALITY',
        payload: {
          overall: combinedReport.qualityScore / 100,
          accuracy: Math.max(0.5, 1 - (combinedReport.issuesFound / combinedReport.totalRecords)),
          completeness: Math.max(0.8, 1 - (allIssues.filter(i => i.issue.includes('Missing')).length / combinedReport.totalRecords))
        }
      });
      
    } catch (error) {
      console.error('Data analysis failed:', error);
    } finally {
      if (showLoading) setIsAnalyzing(false);
    }
  };

  const handleInjectAnomaly = () => {
    dispatch({ type: 'INJECT_ANOMALY' });
    // Re-run analysis after anomaly injection
    setTimeout(() => runDataAnalysis(), 500);
  };

  const handleCorrectAnomalies = () => {
    dispatch({ type: 'CORRECT_ANOMALIES' });
    // Clear issues after correction
    setDataIssues([]);
    setTimeout(() => runDataAnalysis(), 500);
  };

  const handleToggleAutoCorrect = () => {
    const newValue = !autoCorrectEnabled;
    setAutoCorrectEnabled(newValue);
    dataIntegrityEngine.setAutoCorrectEnabled(newValue);
  };

  const filteredIssues = selectedSeverity === 'all' 
    ? dataIssues 
    : dataIssues.filter(issue => issue.severity === selectedSeverity);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-600 bg-red-100 border-red-200';
      case 'high': return 'text-orange-600 bg-orange-100 border-orange-200';
      case 'medium': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'low': return 'text-blue-600 bg-blue-100 border-blue-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const getQualityScoreColor = (score: number) => {
    if (score >= 95) return 'text-green-600 bg-green-100';
    if (score >= 85) return 'text-blue-600 bg-blue-100';
    if (score >= 70) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  return (
    <div className="p-6 space-y-6">
      {/* Enhanced Header */}
      <div className="bg-gradient-to-r from-white via-blue-50 to-indigo-100 rounded-2xl shadow-xl border border-blue-200 p-8">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-4 mb-3">
              <div className="p-4 bg-gradient-to-br from-walmart-blue to-blue-600 rounded-xl shadow-lg">
                <Shield className="w-10 h-10 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-walmart-blue to-blue-600 bg-clip-text text-transparent">
                  AI Data Integrity Engine
                </h1>
                <p className="text-gray-600 mt-1 text-lg">Real-time validation, anomaly detection, and automated correction</p>
              </div>
            </div>
            <div className="flex items-center space-x-6 text-sm">
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full animate-pulse ${autoCorrectEnabled ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                <span className={`font-medium ${autoCorrectEnabled ? 'text-green-600' : 'text-yellow-600'}`}>
                  Auto-Correction {autoCorrectEnabled ? 'Active' : 'Disabled'}
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <Zap className="w-4 h-4 text-blue-500" />
                <span className="text-gray-600">Real-time Monitoring</span>
              </div>
              <div className="flex items-center space-x-2">
                <Database className="w-4 h-4 text-purple-500" />
                <span className="text-gray-600">Multi-source Validation</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="bg-white/90 rounded-xl p-6 shadow-lg border border-blue-200">
              <p className="text-sm text-gray-500 mb-1">Overall Data Quality</p>
              <p className={`text-3xl font-bold ${qualityReport ? getQualityScoreColor(qualityReport.qualityScore).split(' ')[0] : 'text-gray-600'}`}>
                {qualityReport ? `${qualityReport.qualityScore.toFixed(1)}%` : 'Analyzing...'}
              </p>
              <div className="flex items-center justify-end mt-2">
                <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${
                      qualityReport ? getQualityScoreColor(qualityReport.qualityScore).split(' ')[1] : 'bg-gray-400'
                    }`}
                    style={{ width: `${qualityReport ? qualityReport.qualityScore : 0}%` }}
                  ></div>
                </div>
                <span className="text-xs text-gray-600">Score</span>
              </div>
              {qualityReport && (
                <div className="mt-2 text-xs text-gray-500">
                  <div className="flex justify-between">
                    <span>Auto-Corrections:</span>
                    <span className="font-medium text-green-600">{qualityReport.autoCorrectionsApplied}</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Data Quality Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Records Analyzed</h3>
            <Database className="w-6 h-6 text-blue-500" />
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-gray-900 mb-2">
              {qualityReport ? qualityReport.totalRecords.toLocaleString() : '0'}
            </div>
            <p className="text-sm text-gray-600">Supply chain data points</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Issues Detected</h3>
            <AlertTriangle className="w-6 h-6 text-red-500" />
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-gray-900 mb-2">
              {qualityReport ? qualityReport.issuesFound : '0'}
            </div>
            <p className="text-sm text-gray-600">Data anomalies found</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Auto-Corrections</h3>
            <Sparkles className="w-6 h-6 text-green-500" />
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-gray-900 mb-2">
              {qualityReport ? qualityReport.autoCorrectionsApplied : '0'}
            </div>
            <p className="text-sm text-gray-600">AI-powered fixes</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Success Rate</h3>
            <TrendingUp className="w-6 h-6 text-purple-500" />
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-gray-900 mb-2">
              {qualityReport ? `${((qualityReport.issuesCorrected / Math.max(1, qualityReport.issuesFound)) * 100).toFixed(1)}%` : '0%'}
            </div>
            <p className="text-sm text-gray-600">Correction success</p>
          </div>
        </div>
      </div>

      {/* Enhanced Controls */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
          <Settings className="w-6 h-6 mr-2 text-walmart-blue" />
          Data Integrity Controls
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Auto-Correction Toggle */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-700">Auto-Correction</label>
              <button
                onClick={handleToggleAutoCorrect}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  autoCorrectEnabled ? 'bg-green-600' : 'bg-gray-200'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    autoCorrectEnabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
            <p className="text-sm text-gray-600">
              Automatically apply high-confidence corrections to detected data issues.
            </p>
          </div>

          {/* Real-time Monitoring Toggle */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-700">Real-time Monitoring</label>
              <button
                onClick={() => setRealTimeMonitoring(!realTimeMonitoring)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  realTimeMonitoring ? 'bg-blue-600' : 'bg-gray-200'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    realTimeMonitoring ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
            <p className="text-sm text-gray-600">
              Continuously monitor data streams for anomalies and quality issues.
            </p>
          </div>

          {/* Test Controls */}
          <div className="space-y-4">
            <button
              onClick={handleInjectAnomaly}
              className="w-full flex items-center justify-center px-4 py-3 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 transition-colors duration-200"
            >
              <Bug className="w-5 h-5 mr-2" />
              Inject Test Anomaly
            </button>
            <p className="text-sm text-gray-600">
              Simulates data corruption to test the AI validation system's detection capabilities.
            </p>
          </div>

          {/* Analysis Controls */}
          <div className="space-y-4">
            <button
              onClick={() => runDataAnalysis()}
              disabled={isAnalyzing}
              className="w-full flex items-center justify-center px-4 py-3 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors duration-200 disabled:opacity-50"
            >
              {isAnalyzing ? (
                <div className="w-5 h-5 mr-2 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Shield className="w-5 h-5 mr-2" />
              )}
              {isAnalyzing ? 'Analyzing...' : 'Full Data Scan'}
            </button>
            <p className="text-sm text-gray-600">
              Performs comprehensive validation across all supply chain data sources.
            </p>
          </div>
        </div>
      </div>

      {/* Enhanced Data Issues Analysis */}
      {qualityReport && (
        <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Data Quality Analysis</h2>
            <div className="flex items-center space-x-4">
              <select
                value={selectedSeverity}
                onChange={(e) => setSelectedSeverity(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-walmart-blue focus:border-transparent"
              >
                <option value="all">All Severities</option>
                <option value="critical">Critical</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>
          </div>

          {filteredIssues.length > 0 ? (
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {filteredIssues.map((issue) => (
                <div
                  key={issue.id}
                  className={`border rounded-lg p-4 ${getSeverityColor(issue.severity)}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className={`text-xs px-2 py-1 rounded-full font-medium ${getSeverityColor(issue.severity)}`}>
                          {issue.severity.toUpperCase()}
                        </span>
                        <span className="text-sm font-medium text-gray-900">{issue.field}</span>
                        <span className="text-sm text-gray-600">@ {issue.location}</span>
                        {issue.autoApplied && (
                          <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-800 font-medium">
                            AUTO-CORRECTED
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-700 mb-2">{issue.issue}</p>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                        <div>
                          <span className="font-medium text-gray-600">Original:</span>
                          <span className="ml-1 text-gray-900">{String(issue.originalValue)}</span>
                        </div>
                        <div>
                          <span className="font-medium text-gray-600">Corrected:</span>
                          <span className="ml-1 text-green-700 font-medium">{String(issue.correctedValue)}</span>
                        </div>
                        <div>
                          <span className="font-medium text-gray-600">Confidence:</span>
                          <span className="ml-1 text-blue-700 font-medium">{Math.round(issue.confidence * 100)}%</span>
                        </div>
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        <strong>Method:</strong> {issue.correctionMethod}
                      </p>
                      {issue.rootCause && (
                        <p className="text-xs text-gray-500 mt-1">
                          <strong>Root Cause:</strong> {issue.rootCause}
                        </p>
                      )}
                    </div>
                    <div className="ml-4">
                      {issue.autoApplied ? (
                        <Sparkles className="w-5 h-5 text-green-500" />
                      ) : (
                        <CheckCircle className="w-5 h-5 text-blue-500" />
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Data Quality Excellent</h3>
              <p className="text-gray-600">No data integrity issues detected. All systems operating with clean, validated data.</p>
            </div>
          )}
        </div>
      )}

      {/* Quality Categories Breakdown */}
      {qualityReport && Object.keys(qualityReport.categories).length > 0 && (
        <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Issues by Data Category</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(qualityReport.categories).map(([category, stats]) => (
              <div key={category} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <h3 className="font-semibold text-gray-900 mb-2 capitalize">{category.replace('_', ' ')}</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Issues Found:</span>
                    <span className="font-medium text-red-600">{stats.issues}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Corrected:</span>
                    <span className="font-medium text-green-600">{stats.corrections}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Success Rate:</span>
                    <span className="font-medium text-blue-600">
                      {stats.issues > 0 ? Math.round((stats.corrections / stats.issues) * 100) : 100}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recommendations */}
      {qualityReport && qualityReport.recommendations.length > 0 && (
        <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">AI Recommendations</h2>
          <div className="space-y-3">
            {qualityReport.recommendations.map((recommendation, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                <TrendingUp className="w-5 h-5 text-blue-600 mt-0.5" />
                <p className="text-sm text-blue-800">{recommendation}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}