import React, { useState, useEffect } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { prescriptiveOptimizer } from '../utils/optimizer';
import { Target, Brain, Zap, TrendingUp, DollarSign, Clock, Users, Leaf, AlertTriangle, CheckCircle, Settings, Play, Pause, BarChart3 } from 'lucide-react';

export function PrescriptiveActions() {
  const { state, dispatch } = useSimulation();
  const [optimizationObjective, setOptimizationObjective] = useState<'minimize_cost' | 'minimize_time' | 'maximize_satisfaction'>('minimize_cost');
  const [maxBudget, setMaxBudget] = useState(50000);
  const [maxTime, setMaxTime] = useState(48);
  const [minServiceLevel, setMinServiceLevel] = useState(0.95);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizationResults, setOptimizationResults] = useState<any>(null);
  const [autoOptimization, setAutoOptimization] = useState(true);

  // Auto-generate recommendations when conditions change
  useEffect(() => {
    if (autoOptimization && state.isRunning) {
      const interval = setInterval(() => {
        generateOptimizedRecommendations();
      }, 10000); // Every 10 seconds
      
      return () => clearInterval(interval);
    }
  }, [autoOptimization, state.isRunning, optimizationObjective, maxBudget, maxTime, minServiceLevel]);

  const generateOptimizedRecommendations = async () => {
    setIsOptimizing(true);
    
    try {
      // Simulate optimization processing time
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const optimizedActions = prescriptiveOptimizer.generateOptimizedActions(
        state.stores,
        state.distributionCenters,
        state.activeEvent,
        {
          maxBudget,
          maxTime,
          minServiceLevel
        }
      );

      // Add optimized recommendations to the system
      optimizedActions.forEach(action => {
        dispatch({ type: 'ADD_RECOMMENDATION', payload: action });
      });

      // Store optimization results for display
      setOptimizationResults({
        recommendationsGenerated: optimizedActions.length,
        totalCost: optimizedActions.reduce((sum, action) => sum + action.estimatedCost, 0),
        totalTime: Math.max(...optimizedActions.map(action => action.estimatedTimeHours), 0),
        averageConfidence: optimizedActions.length > 0 
          ? optimizedActions.reduce((sum, action) => sum + action.confidence, 0) / optimizedActions.length 
          : 0,
        objective: optimizationObjective,
        timestamp: new Date()
      });

      // Trigger prescriptive analysis
      dispatch({ type: 'TRIGGER_PRESCRIPTIVE_ANALYSIS' });
      
    } catch (error) {
      console.error('Optimization failed:', error);
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleExecuteRecommendation = (recommendationId: string) => {
    dispatch({ type: 'EXECUTE_RECOMMENDATION', payload: recommendationId });
  };

  const pendingRecommendations = state.recommendations.filter(rec => rec.status === 'pending');
  const executingRecommendations = state.recommendations.filter(rec => rec.status === 'executing');
  const completedRecommendations = state.recommendations.filter(rec => rec.status === 'completed');

  const getRecommendationIcon = (type: string) => {
    switch (type) {
      case 'transfer': return <TrendingUp className="w-5 h-5" />;
      case 'supplier-order': return <DollarSign className="w-5 h-5" />;
      case 'staff-allocation': return <Users className="w-5 h-5" />;
      case 'reroute': return <Zap className="w-5 h-5" />;
      case 'price-adjustment': return <BarChart3 className="w-5 h-5" />;
      default: return <Target className="w-5 h-5" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'text-red-600 bg-red-100 border-red-200';
      case 'high': return 'text-orange-600 bg-orange-100 border-orange-200';
      case 'medium': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'low': return 'text-blue-600 bg-blue-100 border-blue-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'executing': return 'text-blue-600 bg-blue-100';
      case 'completed': return 'text-green-600 bg-green-100';
      case 'failed': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Enhanced Header */}
      <div className="bg-gradient-to-r from-white via-purple-50 to-indigo-100 rounded-2xl shadow-xl border border-purple-200 p-8">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-4 mb-3">
              <div className="p-4 bg-gradient-to-br from-walmart-blue to-purple-600 rounded-xl shadow-lg">
                <Brain className="w-10 h-10 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-walmart-blue to-purple-600 bg-clip-text text-transparent">
                  AI Prescriptive Optimizer
                </h1>
                <p className="text-gray-600 mt-1 text-lg">Advanced optimization engine with constraint-based decision making</p>
              </div>
            </div>
            <div className="flex items-center space-x-6 text-sm">
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full animate-pulse ${autoOptimization ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                <span className={`font-medium ${autoOptimization ? 'text-green-600' : 'text-yellow-600'}`}>
                  Auto-Optimization {autoOptimization ? 'Active' : 'Disabled'}
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <Target className="w-4 h-4 text-purple-500" />
                <span className="text-gray-600">Multi-Objective Optimization</span>
              </div>
              <div className="flex items-center space-x-2">
                <Zap className="w-4 h-4 text-blue-500" />
                <span className="text-gray-600">Real-time Constraint Solving</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="bg-white/90 rounded-xl p-6 shadow-lg border border-purple-200">
              <p className="text-sm text-gray-500 mb-1">Engine Confidence</p>
              <p className="text-3xl font-bold text-purple-600">
                {Math.round(state.prescriptiveEngine.confidence * 100)}%
              </p>
              <div className="flex items-center justify-end mt-2">
                <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                  <div 
                    className="h-2 rounded-full transition-all duration-300 bg-purple-500"
                    style={{ width: `${state.prescriptiveEngine.confidence * 100}%` }}
                  ></div>
                </div>
                <span className="text-xs text-gray-600">Accuracy</span>
              </div>
              {optimizationResults && (
                <div className="mt-2 text-xs text-gray-500">
                  <div className="flex justify-between">
                    <span>Last Run:</span>
                    <span className="font-medium">{optimizationResults.recommendationsGenerated} actions</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Optimization Controls */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
          <Settings className="w-6 h-6 mr-2 text-walmart-blue" />
          Optimization Parameters
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Optimization Objective */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-700">Optimization Objective</label>
            <select
              value={optimizationObjective}
              onChange={(e) => setOptimizationObjective(e.target.value as any)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-walmart-blue focus:border-transparent"
            >
              <option value="minimize_cost">Minimize Cost</option>
              <option value="minimize_time">Minimize Time</option>
              <option value="maximize_satisfaction">Maximize Satisfaction</option>
            </select>
            <p className="text-xs text-gray-500">Primary optimization goal for the AI engine</p>
          </div>

          {/* Budget Constraint */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-700">Max Budget ($)</label>
            <input
              type="number"
              value={maxBudget}
              onChange={(e) => setMaxBudget(Number(e.target.value))}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-walmart-blue focus:border-transparent"
              min="1000"
              max="100000"
              step="1000"
            />
            <p className="text-xs text-gray-500">Maximum budget for all recommendations</p>
          </div>

          {/* Time Constraint */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-700">Max Time (hours)</label>
            <input
              type="number"
              value={maxTime}
              onChange={(e) => setMaxTime(Number(e.target.value))}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-walmart-blue focus:border-transparent"
              min="1"
              max="168"
              step="1"
            />
            <p className="text-xs text-gray-500">Maximum execution time for actions</p>
          </div>

          {/* Service Level */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-700">Min Service Level</label>
            <input
              type="number"
              value={minServiceLevel}
              onChange={(e) => setMinServiceLevel(Number(e.target.value))}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-walmart-blue focus:border-transparent"
              min="0.5"
              max="1.0"
              step="0.01"
            />
            <p className="text-xs text-gray-500">Minimum customer service level to maintain</p>
          </div>
        </div>

        <div className="mt-6 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={generateOptimizedRecommendations}
              disabled={isOptimizing}
              className="flex items-center px-6 py-3 bg-walmart-blue text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 disabled:opacity-50"
            >
              {isOptimizing ? (
                <div className="w-5 h-5 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Brain className="w-5 h-5 mr-2" />
              )}
              {isOptimizing ? 'Optimizing...' : 'Generate Recommendations'}
            </button>

            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium text-gray-700">Auto-Optimization</label>
              <button
                onClick={() => setAutoOptimization(!autoOptimization)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  autoOptimization ? 'bg-green-600' : 'bg-gray-200'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    autoOptimization ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>

          {optimizationResults && (
            <div className="text-sm text-gray-600">
              Last optimization: {optimizationResults.timestamp.toLocaleTimeString()} - 
              {optimizationResults.recommendationsGenerated} recommendations generated
            </div>
          )}
        </div>
      </div>

      {/* Optimization Results Summary */}
      {optimizationResults && (
        <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Latest Optimization Results</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium text-blue-900">Recommendations</h3>
                <Target className="w-5 h-5 text-blue-600" />
              </div>
              <p className="text-2xl font-bold text-blue-700">{optimizationResults.recommendationsGenerated}</p>
              <p className="text-sm text-blue-600">Actions generated</p>
            </div>

            <div className="bg-green-50 rounded-lg p-4 border border-green-200">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium text-green-900">Total Cost</h3>
                <DollarSign className="w-5 h-5 text-green-600" />
              </div>
              <p className="text-2xl font-bold text-green-700">${optimizationResults.totalCost.toLocaleString()}</p>
              <p className="text-sm text-green-600">Estimated investment</p>
            </div>

            <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium text-purple-900">Max Time</h3>
                <Clock className="w-5 h-5 text-purple-600" />
              </div>
              <p className="text-2xl font-bold text-purple-700">{optimizationResults.totalTime.toFixed(1)}h</p>
              <p className="text-sm text-purple-600">Execution time</p>
            </div>

            <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium text-yellow-900">Confidence</h3>
                <Brain className="w-5 h-5 text-yellow-600" />
              </div>
              <p className="text-2xl font-bold text-yellow-700">{Math.round(optimizationResults.averageConfidence * 100)}%</p>
              <p className="text-sm text-yellow-600">AI confidence</p>
            </div>
          </div>
        </div>
      )}

      {/* Recommendations Tabs */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <div className="flex items-center py-4 border-b-2 border-walmart-blue text-walmart-blue">
              <Target className="w-5 h-5 mr-2" />
              <span className="font-medium">Pending ({pendingRecommendations.length})</span>
            </div>
          </nav>
        </div>

        <div className="p-6">
          {pendingRecommendations.length > 0 ? (
            <div className="space-y-4">
              {pendingRecommendations.map((recommendation) => (
                <div
                  key={recommendation.id}
                  className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-all duration-200"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className={`p-2 rounded-lg ${getPriorityColor(recommendation.priority)}`}>
                          {getRecommendationIcon(recommendation.type)}
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900 capitalize">
                            {recommendation.type.replace('-', ' ')} Recommendation
                          </h3>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(recommendation.priority)}`}>
                              {recommendation.priority.toUpperCase()}
                            </span>
                            <span>Confidence: {Math.round(recommendation.confidence * 100)}%</span>
                            <span>Success Rate: {Math.round(recommendation.successProbability * 100)}%</span>
                          </div>
                        </div>
                      </div>

                      <p className="text-gray-700 mb-4">{recommendation.reasoning}</p>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div className="bg-gray-50 rounded-lg p-3">
                          <h4 className="font-medium text-gray-900 mb-2">Action Details</h4>
                          <div className="space-y-1 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600">Quantity:</span>
                              <span className="font-medium">{recommendation.quantity} units</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">From:</span>
                              <span className="font-medium">{recommendation.origin}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">To:</span>
                              <span className="font-medium">{recommendation.destination}</span>
                            </div>
                          </div>
                        </div>

                        <div className="bg-gray-50 rounded-lg p-3">
                          <h4 className="font-medium text-gray-900 mb-2">Cost & Time</h4>
                          <div className="space-y-1 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600">Cost:</span>
                              <span className="font-medium">${recommendation.estimatedCost.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Time:</span>
                              <span className="font-medium">{recommendation.estimatedTimeHours.toFixed(1)}h</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Approval:</span>
                              <span className={`font-medium ${recommendation.constraints.requiredApproval ? 'text-yellow-600' : 'text-green-600'}`}>
                                {recommendation.constraints.requiredApproval ? 'Required' : 'Not Required'}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="bg-gray-50 rounded-lg p-3">
                          <h4 className="font-medium text-gray-900 mb-2">Expected Impact</h4>
                          <div className="space-y-1 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600">Revenue:</span>
                              <span className="font-medium text-green-600">+${Math.round(recommendation.expectedImpact.revenueImpact).toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Savings:</span>
                              <span className="font-medium text-blue-600">${Math.round(recommendation.expectedImpact.costSavings).toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Satisfaction:</span>
                              <span className="font-medium text-purple-600">+{recommendation.expectedImpact.customerSatisfactionImprovement.toFixed(1)}%</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {recommendation.riskFactors.length > 0 && (
                        <div className="mb-4">
                          <h4 className="font-medium text-gray-900 mb-2 flex items-center">
                            <AlertTriangle className="w-4 h-4 mr-1 text-yellow-600" />
                            Risk Factors
                          </h4>
                          <div className="flex flex-wrap gap-2">
                            {recommendation.riskFactors.map((risk, index) => (
                              <span key={index} className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">
                                {risk}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {recommendation.alternatives.length > 0 && (
                        <div className="mb-4">
                          <h4 className="font-medium text-gray-900 mb-2">Alternative Options</h4>
                          <div className="space-y-2">
                            {recommendation.alternatives.map((alt, index) => (
                              <div key={index} className="flex items-center justify-between p-2 bg-blue-50 rounded border border-blue-200">
                                <span className="text-sm text-blue-800">{alt.description}</span>
                                <div className="text-xs text-blue-600">
                                  ${alt.cost} • {alt.time}h • {Math.round(alt.confidence * 100)}% confidence
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="ml-6 flex flex-col space-y-2">
                      <button
                        onClick={() => handleExecuteRecommendation(recommendation.id)}
                        className="px-4 py-2 bg-walmart-blue text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 text-sm font-medium"
                      >
                        Execute
                      </button>
                      <div className="text-xs text-gray-500 text-center">
                        Created: {recommendation.createdAt.toLocaleTimeString()}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Target className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No Pending Recommendations</h3>
              <p className="text-gray-600 mb-4">The AI optimizer hasn't identified any actions needed at this time.</p>
              <button
                onClick={generateOptimizedRecommendations}
                disabled={isOptimizing}
                className="px-6 py-3 bg-walmart-blue text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
              >
                Generate New Recommendations
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Executing and Completed Recommendations Summary */}
      {(executingRecommendations.length > 0 || completedRecommendations.length > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Executing */}
          {executingRecommendations.length > 0 && (
            <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse mr-2"></div>
                Executing ({executingRecommendations.length})
              </h3>
              <div className="space-y-3">
                {executingRecommendations.slice(0, 3).map((rec) => (
                  <div key={rec.id} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <div>
                      <p className="font-medium text-blue-900">{rec.type.replace('-', ' ')}</p>
                      <p className="text-sm text-blue-700">{rec.origin} → {rec.destination}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-blue-900">{rec.quantity} units</p>
                      <p className="text-xs text-blue-600">${rec.estimatedCost.toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Completed */}
          {completedRecommendations.length > 0 && (
            <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                Completed ({completedRecommendations.length})
              </h3>
              <div className="space-y-3">
                {completedRecommendations.slice(0, 3).map((rec) => (
                  <div key={rec.id} className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
                    <div>
                      <p className="font-medium text-green-900">{rec.type.replace('-', ' ')}</p>
                      <p className="text-sm text-green-700">{rec.origin} → {rec.destination}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-green-900">{rec.quantity} units</p>
                      <p className="text-xs text-green-600">✓ Success</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}