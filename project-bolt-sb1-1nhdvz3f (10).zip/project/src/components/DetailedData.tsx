import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { Database, FileText, Globe, BarChart3 } from 'lucide-react';

export function DetailedData() {
  const { state } = useSimulation();
  const [activeTab, setActiveTab] = useState<'data' | 'logs' | 'walmart'>('data');

  const tabs = [
    { id: 'data' as const, label: 'Raw Data', icon: Database },
    { id: 'logs' as const, label: 'Event Logs', icon: FileText },
    { id: 'walmart' as const, label: 'Walmart.com Simulation', icon: Globe },
  ];

  const renderDataTables = () => (
    <div className="space-y-6">
      {/* Stores Data */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Store Inventory Data</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Store ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Region</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Current Stock</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Safety Stock</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Reorder Point</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Daily Sales Avg</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {state.stores.map((store) => (
                <tr key={store.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{store.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{store.region}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{Math.round(store.currentStock)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{store.safetyStock}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{store.reorderPoint}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{store.dailySalesAvg}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Distribution Centers Data */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Distribution Center Data</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">DC ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Region</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Current Stock</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Capacity</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Utilization</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {state.distributionCenters.map((dc) => (
                <tr key={dc.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{dc.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{dc.region}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{dc.currentStock.toLocaleString()}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{dc.capacity.toLocaleString()}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {Math.round((dc.currentStock / dc.capacity) * 100)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Active Shipments */}
      {state.shipments.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Active Shipments</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Shipment ID</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product SKU</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Origin</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Destination</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ETA (hours)</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {state.shipments.map((shipment) => (
                  <tr key={shipment.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{shipment.id}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{shipment.productSku}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{shipment.quantity}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{shipment.origin}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{shipment.destination}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{shipment.etaHours}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );

  const renderEventLogs = () => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">System Event Log</h3>
      <div className="space-y-3 max-h-96 overflow-y-auto">
        {state.eventLog.slice().reverse().map((log, index) => (
          <div key={index} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
            <div className="flex-shrink-0 w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
            <div className="flex-1">
              <p className="text-sm text-gray-900">{log.message}</p>
              <p className="text-xs text-gray-500 mt-1">{log.timestamp.toLocaleString()}</p>
            </div>
          </div>
        ))}
        {state.eventLog.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No events logged yet</p>
          </div>
        )}
      </div>
    </div>
  );

  const renderWalmartSimulation = () => {
    const demoStore = state.stores[0];
    const stockLevel = demoStore ? Math.round(demoStore.currentStock) : 0;
    const stockStatus = stockLevel <= 0 ? 'Out of Stock' : stockLevel < 20 ? 'Low Stock' : 'In Stock';
    const statusColor = stockLevel <= 0 ? 'text-red-600' : stockLevel < 20 ? 'text-yellow-600' : 'text-green-600';

    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Live Walmart.com Product Status</h3>
        
        <div className="max-w-2xl mx-auto">
          {/* Mock Walmart Product Page */}
          <div className="border border-gray-200 rounded-lg p-6 bg-gray-50">
            <div className="flex items-start space-x-6">
              {/* Product Image */}
              <div className="flex-shrink-0">
                <img
                  src="https://images.pexels.com/photos/4226721/pexels-photo-4226721.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop"
                  alt="AI-Powered Smart Air Fryer Pro"
                  className="w-32 h-32 object-cover rounded-lg"
                />
              </div>
              
              {/* Product Details */}
              <div className="flex-1">
                <h4 className="text-xl font-bold text-gray-900 mb-2">AI-Powered Smart Air Fryer Pro</h4>
                <p className="text-gray-600 mb-3">Model: AF-PRO-2025</p>
                <p className="text-2xl font-bold text-walmart-blue mb-4">$59.99</p>
                
                {/* Stock Status */}
                <div className="mb-4">
                  <p className={`text-lg font-semibold ${statusColor}`}>
                    {stockStatus}
                    {stockLevel > 0 && ` (${stockLevel} available)`}
                  </p>
                  {demoStore && (
                    <p className="text-sm text-gray-600">at {demoStore.name}</p>
                  )}
                </div>
                
                {/* Action Buttons */}
                <div className="space-y-2">
                  <button
                    disabled={stockLevel <= 0}
                    className={`w-full py-3 px-6 rounded-lg font-semibold ${
                      stockLevel > 0
                        ? 'bg-walmart-blue text-white hover:bg-blue-700'
                        : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    {stockLevel > 0 ? 'Add to Cart' : 'Notify When Available'}
                  </button>
                  
                  <button className="w-full py-2 px-6 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                    Find in Other Stores
                  </button>
                </div>
              </div>
            </div>
            
            {/* Stock Alert */}
            {stockLevel < 20 && stockLevel > 0 && (
              <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-sm text-yellow-800">
                  <strong>Limited Stock:</strong> Only {stockLevel} left! Order soon.
                </p>
              </div>
            )}
            
            {stockLevel <= 0 && (
              <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-800">
                  <strong>Out of Stock:</strong> This item is currently unavailable. We'll notify you when it's back.
                </p>
              </div>
            )}
          </div>
          
          {/* Real-time Updates Notice */}
          <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center">
              <BarChart3 className="w-5 h-5 text-blue-600 mr-2" />
              <p className="text-sm text-blue-800">
                <strong>Real-time Integration:</strong> Stock levels update automatically based on the simulation.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Detailed Data & Logs</h1>
            <p className="text-gray-600 mt-1">Comprehensive view of all system data and operational logs</p>
          </div>
          <Database className="w-8 h-8 text-walmart-blue" />
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`
                    flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200
                    ${isActive
                      ? 'border-walmart-blue text-walmart-blue'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }
                  `}
                >
                  <Icon className="w-5 h-5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="p-6">
          {activeTab === 'data' && renderDataTables()}
          {activeTab === 'logs' && renderEventLogs()}
          {activeTab === 'walmart' && renderWalmartSimulation()}
        </div>
      </div>
    </div>
  );
}