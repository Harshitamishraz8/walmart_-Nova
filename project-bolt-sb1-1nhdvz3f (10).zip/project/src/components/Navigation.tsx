import React from 'react';
import { BarChart3, Shield, Zap, Target, Database, Sparkles } from 'lucide-react';
import type { TabType } from '../App';

interface NavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

export function Navigation({ activeTab, onTabChange }: NavigationProps) {
  const tabs = [
    { id: 'dashboard' as TabType, label: 'Command Center', icon: BarChart3 },
    { id: 'data-integrity' as TabType, label: 'Data Integrity', icon: Shield },
    { id: 'event-simulation' as TabType, label: 'Event Simulation', icon: Zap },
    { id: 'prescriptive-actions' as TabType, label: 'AI Recommendations', icon: Target },
    { id: 'detailed-data' as TabType, label: 'Analytics Hub', icon: Database },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-md shadow-lg z-50 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-walmart-blue to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-walmart-blue to-blue-600 bg-clip-text text-transparent">
                Walmart AI Navigator
              </h1>
              <p className="text-xs text-gray-500">Prescriptive Analytics Platform</p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex space-x-1 bg-gray-100 rounded-xl p-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              
              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  className={`
                    flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300
                    ${isActive 
                      ? 'bg-white text-walmart-blue shadow-md transform scale-105' 
                      : 'text-gray-600 hover:text-gray-900 hover:bg-white/50'
                    }
                  `}
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden md:block">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
}