import React from 'react';
import { useSimulation } from '../../context/SimulationContext';
import { MapPin, Warehouse, AlertTriangle, CheckCircle, Clock } from 'lucide-react';

export function SupplyChainMap() {
  const { state } = useSimulation();

  const getCriticalStores = () => {
    return state.stores.filter(store => store.currentStock < store.safetyStock);
  };

  const getStoreStatus = (store: any) => {
    if (store.currentStock <= 0) return { status: 'out-of-stock', color: 'bg-red-500', textColor: 'text-red-600' };
    if (store.currentStock < store.safetyStock) return { status: 'critical', color: 'bg-red-400', textColor: 'text-red-600' };
    if (store.currentStock < store.reorderPoint) return { status: 'low', color: 'bg-yellow-400', textColor: 'text-yellow-600' };
    return { status: 'healthy', color: 'bg-green-400', textColor: 'text-green-600' };
  };

  const criticalStores = getCriticalStores();

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-gray-900">Supply Chain Network</h2>
        <div className="flex items-center space-x-4 text-sm">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-400 rounded-full"></div>
            <span className="text-gray-600">Healthy</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
            <span className="text-gray-600">Low Stock</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-400 rounded-full"></div>
            <span className="text-gray-600">Critical</span>
          </div>
        </div>
      </div>

      {/* Mock Map Container */}
      <div className="relative bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg h-96 overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#4F46E5" strokeWidth="0.5"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        {/* Distribution Centers */}
        {state.distributionCenters.map((dc, index) => (
          <div
            key={dc.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2"
            style={{
              left: `${20 + index * 60}%`,
              top: `${30}%`,
            }}
          >
            <div className="flex flex-col items-center">
              <div className="relative">
                <div className="bg-blue-600 p-3 rounded-lg shadow-lg">
                  <Warehouse className="w-6 h-6 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 bg-green-500 w-4 h-4 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-3 h-3 text-white" />
                </div>
              </div>
              <div className="bg-white px-2 py-1 rounded shadow-sm mt-2 text-xs font-medium">
                {dc.name.split(' ')[0]} DC
              </div>
              <div className="text-xs text-gray-600">{dc.currentStock} units</div>
            </div>
          </div>
        ))}

        {/* Stores */}
        {state.stores.map((store, index) => {
          const status = getStoreStatus(store);
          const row = Math.floor(index / 3);
          const col = index % 3;
          
          return (
            <div
              key={store.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2"
              style={{
                left: `${15 + col * 25}%`,
                top: `${60 + row * 25}%`,
              }}
            >
              <div className="flex flex-col items-center">
                <div className="relative">
                  <div className={`p-2 rounded-lg shadow-lg ${status.color}`}>
                    <MapPin className="w-4 h-4 text-white" />
                  </div>
                  {status.status === 'critical' && (
                    <div className="absolute -top-1 -right-1 bg-red-600 w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                      <AlertTriangle className="w-3 h-3 text-white" />
                    </div>
                  )}
                </div>
                <div className="bg-white px-2 py-1 rounded shadow-sm mt-1 text-xs font-medium">
                  {store.id}
                </div>
                <div className={`text-xs font-medium ${status.textColor}`}>
                  {Math.round(store.currentStock)} units
                </div>
              </div>
            </div>
          );
        })}

        {/* Active Shipments */}
        {state.shipments.map((shipment, index) => (
          <div
            key={shipment.id}
            className="absolute"
            style={{
              left: `${30 + index * 15}%`,
              top: `${45}%`,
            }}
          >
            <div className="flex items-center bg-purple-100 border border-purple-200 rounded-lg px-2 py-1">
              <Clock className="w-3 h-3 text-purple-600 mr-1" />
              <span className="text-xs text-purple-700">
                {shipment.quantity} units ({shipment.etaHours}h)
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Critical Stores Alert */}
      {criticalStores.length > 0 && (
        <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center">
            <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />
            <h3 className="text-sm font-medium text-red-800">Critical Stock Levels Detected</h3>
          </div>
          <div className="mt-2 text-sm text-red-700">
            {criticalStores.length} store{criticalStores.length !== 1 ? 's' : ''} require immediate attention:
            <span className="ml-2 font-medium">
              {criticalStores.map(s => s.id).join(', ')}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}