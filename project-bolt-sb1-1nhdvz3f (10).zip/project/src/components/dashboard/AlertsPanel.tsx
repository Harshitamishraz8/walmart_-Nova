import React from 'react';
import { useSimulation } from '../../context/SimulationContext';
import { AlertTriangle, Clock, CheckCircle } from 'lucide-react';

export function AlertsPanel() {
  const { state } = useSimulation();

  const getCriticalAlerts = () => {
    const alerts = [];
    
    // Critical stock alerts
    state.stores.forEach(store => {
      if (store.currentStock <= 0) {
        alerts.push({
          id: `stockout-${store.id}`,
          type: 'critical',
          title: 'Stock Out',
          message: `${store.id} is completely out of stock`,
          timestamp: new Date(),
        });
      } else if (store.currentStock < store.safetyStock) {
        const hoursRemaining = Math.round(store.currentStock / (store.dailySalesAvg / 24));
        alerts.push({
          id: `critical-${store.id}`,
          type: 'warning',
          title: 'Critical Stock Level',
          message: `${store.id} has only ${Math.round(store.currentStock)} units (${hoursRemaining}h remaining)`,
          timestamp: new Date(),
        });
      }
    });

    // Active event alerts
    if (state.activeEvent) {
      alerts.push({
        id: `event-${state.activeEvent.id}`,
        type: 'info',
        title: 'Active Event',
        message: `${state.activeEvent.type} in ${state.activeEvent.region}: ${state.activeEvent.description}`,
        timestamp: new Date(),
      });
    }

    return alerts.sort((a, b) => {
      const priority = { critical: 3, warning: 2, info: 1 };
      return priority[b.type as keyof typeof priority] - priority[a.type as keyof typeof priority];
    });
  };

  const alerts = getCriticalAlerts();

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'critical':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'warning':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'info':
        return <CheckCircle className="w-4 h-4 text-blue-500" />;
      default:
        return <CheckCircle className="w-4 h-4 text-gray-500" />;
    }
  };

  const getAlertStyle = (type: string) => {
    switch (type) {
      case 'critical':
        return 'bg-red-50 border-red-200';
      case 'warning':
        return 'bg-yellow-50 border-yellow-200';
      case 'info':
        return 'bg-blue-50 border-blue-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gray-900">System Alerts</h2>
        {alerts.length > 0 && (
          <span className="bg-red-100 text-red-800 text-xs font-medium px-2 py-1 rounded-full">
            {alerts.length} active
          </span>
        )}
      </div>

      <div className="space-y-3 max-h-80 overflow-y-auto">
        {alerts.length > 0 ? (
          alerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-3 rounded-lg border ${getAlertStyle(alert.type)} transition-all duration-200 hover:shadow-sm`}
            >
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0 mt-0.5">
                  {getAlertIcon(alert.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900">{alert.title}</p>
                  <p className="text-sm text-gray-600 mt-1">{alert.message}</p>
                  <p className="text-xs text-gray-500 mt-2">
                    {alert.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8">
            <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
            <p className="text-gray-600 text-sm">All systems operational</p>
            <p className="text-gray-500 text-xs mt-1">No alerts at this time</p>
          </div>
        )}
      </div>
    </div>
  );
}