import React from 'react';
import { useSimulation } from '../../context/SimulationContext';
import { TrendingUp, Package, DollarSign, Shield, Users, Zap, Brain, Target, AlertTriangle, CheckCircle } from 'lucide-react';

export function KPICards() {
  const { state } = useSimulation();

  const criticalStores = state.stores.filter(store => 
    store.currentStock < store.safetyStock * 0.5 || 
    (store.currentStock / (store.dailySalesAvg / 24)) < 24
  );

  const totalRevenueProtected = state.recommendations
    .filter(rec => rec.status === 'completed')
    .reduce((sum, rec) => sum + rec.expectedImpact.revenueImpact, 0);

  const avgConfidence = state.recommendations.length > 0 
    ? state.recommendations.reduce((sum, rec) => sum + rec.confidence, 0) / state.recommendations.length 
    : 0;

  const kpis = [
    {
      label: 'Stockouts Averted',
      value: state.kpis.stockoutsAverted,
      icon: Shield,
      color: 'text-green-600',
      bgColor: 'bg-gradient-to-br from-green-50 to-green-100',
      borderColor: 'border-green-200',
      change: '+12%',
      changeType: 'positive' as const,
      description: 'AI prevented stockouts',
      trend: 'up',
    },
    {
      label: 'Units Optimized',
      value: state.kpis.unitsTransferred.toLocaleString(),
      icon: Package,
      color: 'text-blue-600',
      bgColor: 'bg-gradient-to-br from-blue-50 to-blue-100',
      borderColor: 'border-blue-200',
      change: '+8%',
      changeType: 'positive' as const,
      description: 'Inventory flow optimized',
      trend: 'up',
    },
    {
      label: 'Cost Savings',
      value: `$${Math.round(state.kpis.costSavings).toLocaleString()}`,
      icon: DollarSign,
      color: 'text-purple-600',
      bgColor: 'bg-gradient-to-br from-purple-50 to-purple-100',
      borderColor: 'border-purple-200',
      change: '+15%',
      changeType: 'positive' as const,
      description: 'Through AI optimization',
      trend: 'up',
    },
    {
      label: 'Revenue Protected',
      value: `$${Math.round(totalRevenueProtected).toLocaleString()}`,
      icon: Target,
      color: 'text-indigo-600',
      bgColor: 'bg-gradient-to-br from-indigo-50 to-indigo-100',
      borderColor: 'border-indigo-200',
      change: '+22%',
      changeType: 'positive' as const,
      description: 'Sales preserved',
      trend: 'up',
    },
    {
      label: 'Customer Satisfaction',
      value: `${state.kpis.customerSatisfaction.toFixed(1)}%`,
      icon: Users,
      color: 'text-walmart-blue',
      bgColor: 'bg-gradient-to-br from-blue-50 to-walmart-blue/10',
      borderColor: 'border-blue-200',
      change: '+2.3%',
      changeType: 'positive' as const,
      description: 'Service levels maintained',
      trend: 'up',
    },
    {
      label: 'Critical Stores',
      value: criticalStores.length,
      icon: AlertTriangle,
      color: criticalStores.length > 0 ? 'text-red-600' : 'text-green-600',
      bgColor: criticalStores.length > 0 ? 'bg-gradient-to-br from-red-50 to-red-100' : 'bg-gradient-to-br from-green-50 to-green-100',
      borderColor: criticalStores.length > 0 ? 'border-red-200' : 'border-green-200',
      change: '-23%',
      changeType: 'positive' as const,
      description: 'Requiring immediate action',
      trend: 'down',
    },
    {
      label: 'AI Recommendations',
      value: state.prescriptiveEngine.recommendationsGenerated,
      icon: Brain,
      color: 'text-yellow-600',
      bgColor: 'bg-gradient-to-br from-yellow-50 to-yellow-100',
      borderColor: 'border-yellow-200',
      change: 'Active',
      changeType: 'neutral' as const,
      description: 'Generated this session',
      trend: 'stable',
    },
    {
      label: 'Engine Confidence',
      value: `${Math.round(avgConfidence * 100)}%`,
      icon: Zap,
      color: 'text-emerald-600',
      bgColor: 'bg-gradient-to-br from-emerald-50 to-emerald-100',
      borderColor: 'border-emerald-200',
      change: '+5%',
      changeType: 'positive' as const,
      description: 'Model accuracy',
      trend: 'up',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-8 gap-4">
      {kpis.map((kpi, index) => {
        const Icon = kpi.icon;
        return (
          <div 
            key={index} 
            className={`${kpi.bgColor} rounded-xl shadow-lg border-2 ${kpi.borderColor} p-6 hover:shadow-xl transition-all duration-300 hover:scale-105 group`}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-white rounded-lg shadow-sm group-hover:shadow-md transition-shadow duration-300">
                <Icon className={`w-6 h-6 ${kpi.color}`} />
              </div>
              <div className={`text-sm font-medium px-3 py-1 rounded-full ${
                kpi.changeType === 'positive' 
                  ? 'text-green-600 bg-green-100' 
                  : kpi.changeType === 'negative'
                  ? 'text-red-600 bg-red-100'
                  : 'text-blue-600 bg-blue-100'
              }`}>
                {kpi.trend === 'up' && <TrendingUp className="w-3 h-3 inline mr-1" />}
                {kpi.trend === 'down' && <TrendingUp className="w-3 h-3 inline mr-1 transform rotate-180" />}
                {kpi.trend === 'stable' && <CheckCircle className="w-3 h-3 inline mr-1" />}
                {kpi.change}
              </div>
            </div>
            <div>
              <p className="text-3xl font-bold text-gray-900 mb-1 group-hover:text-gray-800 transition-colors duration-300">
                {kpi.value}
              </p>
              <p className="text-sm font-medium text-gray-700 mb-1">{kpi.label}</p>
              <p className="text-xs text-gray-500">{kpi.description}</p>
            </div>
            
            {/* Progress indicator for some metrics */}
            {(kpi.label.includes('Confidence') || kpi.label.includes('Satisfaction')) && (
              <div className="mt-3">
                <div className="w-full bg-gray-200 rounded-full h-1.5">
                  <div
                    className={`h-1.5 rounded-full transition-all duration-500 ${
                      kpi.label.includes('Confidence') ? 'bg-emerald-500' : 'bg-blue-500'
                    }`}
                    style={{ 
                      width: `${kpi.label.includes('Confidence') ? avgConfidence * 100 : state.kpis.customerSatisfaction}%` 
                    }}
                  ></div>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}