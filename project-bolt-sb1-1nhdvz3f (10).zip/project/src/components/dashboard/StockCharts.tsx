import React from 'react';
import { useSimulation } from '../../context/SimulationContext';
import { BarChart3, TrendingDown, TrendingUp } from 'lucide-react';

export function StockCharts() {
  const { state } = useSimulation();

  const getStockLevel = (current: number, safety: number) => {
    const percentage = (current / safety) * 100;
    if (percentage <= 50) return { level: 'critical', color: 'bg-red-500' };
    if (percentage <= 100) return { level: 'low', color: 'bg-yellow-500' };
    if (percentage <= 150) return { level: 'healthy', color: 'bg-green-500' };
    return { level: 'surplus', color: 'bg-blue-500' };
  };

  const getTrend = (store: any) => {
    // Simulate trend calculation
    const hourlyDemand = store.dailySalesAvg / 24;
    const hoursRemaining = store.currentStock / hourlyDemand;
    return hoursRemaining < 48 ? 'down' : 'up';
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Store Inventory Levels */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-gray-900">Store Inventory Levels</h2>
          <BarChart3 className="w-5 h-5 text-gray-400" />
        </div>
        
        <div className="space-y-4">
          {state.stores.map((store) => {
            const stockLevel = getStockLevel(store.currentStock, store.safetyStock);
            const trend = getTrend(store);
            const percentage = Math.min(100, (store.currentStock / (store.safetyStock * 2)) * 100);
            
            return (
              <div key={store.id} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-900">{store.id}</span>
                    <span className="text-xs text-gray-500">({store.region})</span>
                    {trend === 'down' ? (
                      <TrendingDown className="w-4 h-4 text-red-500" />
                    ) : (
                      <TrendingUp className="w-4 h-4 text-green-500" />
                    )}
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-semibold text-gray-900">
                      {Math.round(store.currentStock)}
                    </span>
                    <span className="text-xs text-gray-500 ml-1">/ {store.safetyStock}</span>
                  </div>
                </div>
                
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all duration-300 ${stockLevel.color}`}
                    style={{ width: `${percentage}%` }}
                  ></div>
                </div>
                
                <div className="flex justify-between text-xs text-gray-500">
                  <span>Safety: {store.safetyStock}</span>
                  <span>Daily Avg: {store.dailySalesAvg}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Distribution Center Status */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-gray-900">Distribution Centers</h2>
          <BarChart3 className="w-5 h-5 text-gray-400" />
        </div>
        
        <div className="space-y-6">
          {state.distributionCenters.map((dc) => {
            const utilizationPercentage = (dc.currentStock / dc.capacity) * 100;
            
            return (
              <div key={dc.id} className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium text-gray-900">{dc.name}</h3>
                  <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                    Operational
                  </span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-500">Current Stock</p>
                    <p className="font-semibold text-gray-900">{dc.currentStock.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Capacity</p>
                    <p className="font-semibold text-gray-900">{dc.capacity.toLocaleString()}</p>
                  </div>
                </div>
                
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Utilization</span>
                    <span>{Math.round(utilizationPercentage)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="h-2 rounded-full transition-all duration-300 bg-blue-500"
                      style={{ width: `${utilizationPercentage}%` }}
                    ></div>
                  </div>
                </div>
                
                {dc !== state.distributionCenters[state.distributionCenters.length - 1] && (
                  <hr className="border-gray-200" />
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}