import React from 'react';
import { useSimulation } from '../../context/SimulationContext';
import { Play, Pause, RotateCcw, Settings } from 'lucide-react';

export function SimulationControls() {
  const { state, dispatch } = useSimulation();

  const handleStartPause = () => {
    if (state.isRunning) {
      dispatch({ type: 'PAUSE_SIMULATION' });
    } else {
      dispatch({ type: 'START_SIMULATION' });
    }
  };

  const handleReset = () => {
    dispatch({ type: 'RESET_SIMULATION' });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gray-900">Simulation Controls</h2>
        <Settings className="w-5 h-5 text-gray-400" />
      </div>

      <div className="space-y-4">
        {/* Status */}
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <span className="text-sm font-medium text-gray-700">Status</span>
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${state.isRunning ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}></div>
            <span className="text-sm text-gray-600">
              {state.isRunning ? 'Running' : 'Paused'}
            </span>
          </div>
        </div>

        {/* Time */}
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <span className="text-sm font-medium text-gray-700">Simulation Time</span>
          <span className="text-sm text-gray-900 font-semibold">
            {Math.floor(state.simulationTime / 24)}d {state.simulationTime % 24}h
          </span>
        </div>

        {/* Controls */}
        <div className="flex space-x-2">
          <button
            onClick={handleStartPause}
            className={`flex items-center justify-center flex-1 px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
              state.isRunning
                ? 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200'
                : 'bg-walmart-blue text-white hover:bg-blue-700'
            }`}
          >
            {state.isRunning ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
            {state.isRunning ? 'Pause' : 'Start'}
          </button>
          
          <button
            onClick={handleReset}
            className="flex items-center justify-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors duration-200"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </button>
        </div>

        {/* Progress */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-gray-500">
            <span>Progress</span>
            <span>{Math.round((state.simulationTime / 168) * 100)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-walmart-blue h-2 rounded-full transition-all duration-300"
              style={{ width: `${Math.min(100, (state.simulationTime / 168) * 100)}%` }}
            ></div>
          </div>
          <p className="text-xs text-gray-500">Maximum: 7 days (168 hours)</p>
        </div>
      </div>
    </div>
  );
}