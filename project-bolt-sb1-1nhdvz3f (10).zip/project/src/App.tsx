import React, { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation';
import { Dashboard } from './components/Dashboard';
import { DataIntegrity } from './components/DataIntegrity';
import { EventSimulation } from './components/EventSimulation';
import { PrescriptiveActions } from './components/PrescriptiveActions';
import { DetailedData } from './components/DetailedData';
import { SimulationProvider } from './context/SimulationContext';

export type TabType = 'dashboard' | 'data-integrity' | 'event-simulation' | 'prescriptive-actions' | 'detailed-data';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'data-integrity':
        return <DataIntegrity />;
      case 'event-simulation':
        return <EventSimulation />;
      case 'prescriptive-actions':
        return <PrescriptiveActions />;
      case 'detailed-data':
        return <DetailedData />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <SimulationProvider>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
        <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
        <main className="pt-16">
          {renderActiveTab()}
        </main>
      </div>
    </SimulationProvider>
  );
}

export default App;