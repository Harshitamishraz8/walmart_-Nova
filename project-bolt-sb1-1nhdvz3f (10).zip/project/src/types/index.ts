export interface Store {
  id: string;
  name: string;
  region: string;
  currentStock: number;
  safetyStock: number;
  reorderPoint: number;
  dailySalesAvg: number;
  lat: number;
  lng: number;
  maxCapacity: number;
  operationalStatus: 'operational' | 'limited' | 'closed';
  lastRestockDate: Date;
  avgLeadTime: number;
  demandPattern: 'stable' | 'seasonal' | 'volatile';
  customerSegment: 'premium' | 'standard' | 'economy';
  fulfillmentCapacity: number;
  staffCount: number;
  automationLevel: number;
  priority: 'high' | 'medium' | 'low';
  riskScore: number;
  performanceScore: number;
}

export interface DistributionCenter {
  id: string;
  name: string;
  region: string;
  currentStock: number;
  capacity: number;
  lat: number;
  lng: number;
  operationalStatus: 'operational' | 'limited' | 'closed';
  throughputCapacity: number;
  connectedStores: string[];
  automationLevel: number;
  energyEfficiency: number;
  sustainabilityScore: number;
  costPerUnit: number;
  avgProcessingTime: number;
}

export interface Event {
  id: string;
  type: 'demand-surge' | 'weather-alert' | 'road-closure' | 'competitor-opening' | 'flash-sale' | 'supplier-delay' | 'labor-shortage' | 'cyber-attack' | 'natural-disaster';
  region: string;
  description: string;
  demandMultiplier: number;
  impactSku?: string;
  routeAffected?: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  duration: number;
  startTime: number;
  probability: number;
  economicImpact: number;
  customerImpact: number;
  environmentalImpact: number;
  mitigationStrategies: string[];
  expectedResolution: number;
}

export interface Recommendation {
  id: string;
  type: 'transfer' | 'supplier-order' | 'reroute' | 'staff-allocation' | 'customer-communication' | 'price-adjustment' | 'promotion-halt' | 'emergency-procurement' | 'capacity-scaling';
  productSku: string;
  quantity: number;
  origin: string;
  destination: string;
  estimatedCost: number;
  estimatedTimeHours: number;
  status: 'pending' | 'executing' | 'completed' | 'failed' | 'cancelled';
  reasoning: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  confidence: number;
  expectedImpact: {
    stockoutPrevention: boolean;
    customerSatisfactionImprovement: number;
    costSavings: number;
    revenueImpact: number;
    operationalEfficiency: number;
    environmentalBenefit: number;
    riskReduction: number;
  };
  constraints: {
    maxCost: number;
    maxTime: number;
    minQuantity: number;
    requiredApproval: boolean;
    sustainabilityRequirements: string[];
  };
  alternatives: Array<{
    description: string;
    cost: number;
    time: number;
    confidence: number;
    environmentalImpact: number;
  }>;
  riskFactors: string[];
  successProbability: number;
  createdAt: Date;
  executedAt?: Date;
  completedAt?: Date;
  mlModelUsed: string;
  dataQualityScore: number;
  businessImpactScore: number;
  kpiImpact: {
    fillRate: number;
    inventoryTurnover: number;
    customerSatisfaction: number;
    operationalCost: number;
  };
}

export interface Shipment {
  id: string;
  productSku: string;
  quantity: number;
  origin: string;
  destination: string;
  etaHours: number;
  type: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  cost: number;
  route: string[];
  trackingStatus: 'dispatched' | 'in-transit' | 'delayed' | 'delivered' | 'cancelled';
  delayReason?: string;
  carbonFootprint: number;
  fuelConsumption: number;
  driverInfo: {
    id: string;
    name: string;
    rating: number;
    hoursOnDuty: number;
  };
  realTimeLocation?: {
    lat: number;
    lng: number;
    timestamp: Date;
  };
}

export interface AIModel {
  name: string;
  type: 'demand-forecasting' | 'inventory-optimization' | 'route-optimization' | 'anomaly-detection' | 'price-optimization' | 'customer-behavior' | 'sustainability-optimization';
  accuracy: number;
  lastTrained: Date;
  confidence: number;
  status: 'active' | 'training' | 'offline' | 'deprecated';
  version: string;
  trainingDataSize: number;
  computeResources: string;
  energyConsumption: number;
  biasScore: number;
  explainabilityScore: number;
  performanceMetrics: {
    precision: number;
    recall: number;
    f1Score: number;
    auc: number;
  };
}

export interface DataQualityMetrics {
  completeness: number;
  accuracy: number;
  consistency: number;
  timeliness: number;
  validity: number;
  overall: number;
  anomaliesDetected: number;
  anomaliesCorrected: number;
  dataFreshness: number;
  sourceReliability: number;
  trendAnalysis: {
    improvementRate: number;
    qualityTrend: 'improving' | 'stable' | 'declining';
    criticalIssues: number;
  };
}

export interface PerformanceMetrics {
  stockoutRate: number;
  fillRate: number;
  inventoryTurnover: number;
  customerSatisfaction: number;
  operationalCost: number;
  responseTime: number;
  sustainabilityScore: number;
  carbonEfficiency: number;
  energyEfficiency: number;
  wasteReduction: number;
  socialImpactScore: number;
  innovationIndex: number;
  profitability: {
    grossMargin: number;
    netMargin: number;
    roi: number;
    costPerOrder: number;
  };
}

export interface BusinessKPI {
  name: string;
  currentValue: number;
  targetValue: number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  changePercent: number;
  lastUpdated: Date;
  category: 'financial' | 'operational' | 'customer' | 'sustainability' | 'innovation' | 'social';
  benchmarkComparison: number;
  strategicImportance: 'low' | 'medium' | 'high' | 'critical';
  alertThreshold: number;
  isAlert: boolean;
}

export interface OptimizationConstraints {
  maxBudget: number;
  maxDeliveryTime: number;
  minServiceLevel: number;
  maxVehicleUtilization: number;
  environmentalLimits: {
    maxCO2Emissions: number;
    maxEnergyConsumption: number;
    minRenewableEnergyPercent: number;
    maxWasteGeneration: number;
    preferredFuelTypes: string[];
  };
  businessRules: {
    workingHours: { start: number; end: number };
    weekendOperations: boolean;
    holidayRestrictions: string[];
    unionRequirements: string[];
    safetyProtocols: string[];
  };
  socialResponsibility: {
    minLocalSourcing: number;
    maxChildLaborRisk: number;
    minFairTradePercent: number;
    communityInvestmentRequired: boolean;
  };
  innovationTargets: {
    minAutomationLevel: number;
    maxManualProcesses: number;
    requiredTechStack: string[];
    aiEthicsCompliance: boolean;
  };
  riskManagement: {
    maxRiskExposure: number;
    diversificationRequirements: string[];
    contingencyPlans: string[];
  };
}

export interface RealTimeAlert {
  id: string;
  type: 'critical' | 'warning' | 'info' | 'success';
  title: string;
  message: string;
  timestamp: Date;
  source: string;
  affectedEntities: string[];
  recommendedActions: string[];
  escalationLevel: number;
  isAcknowledged: boolean;
  resolvedAt?: Date;
  severity: number;
  businessImpact: 'low' | 'medium' | 'high' | 'critical';
  technicalDetails: Record<string, any>;
  automatedResponse: boolean;
  humanInterventionRequired: boolean;
  estimatedResolutionTime: number;
}

export interface Vehicle {
  id: string;
  type: 'truck' | 'van' | 'drone' | 'autonomous-vehicle' | 'electric-truck';
  capacity: number;
  currentLocation: string;
  status: 'available' | 'in-transit' | 'loading' | 'maintenance' | 'charging';
  fuelEfficiency: number;
  operatingCostPerMile: number;
  maxRange: number;
  fuelType: 'diesel' | 'gasoline' | 'electric' | 'hydrogen' | 'hybrid';
  emissionsFactor: number;
  maintenanceScore: number;
  driverAssigned?: string;
  autonomyLevel: number;
  safetyRating: number;
  lastMaintenanceDate: Date;
  predictedMaintenanceDate: Date;
  utilizationRate: number;
  costPerDelivery: number;
}

export interface Route {
  id: string;
  origin: string;
  destination: string;
  distance: number;
  estimatedTime: number;
  trafficCondition: 'light' | 'moderate' | 'heavy' | 'severe';
  weatherImpact: 'none' | 'minor' | 'moderate' | 'severe';
  roadCondition: 'excellent' | 'good' | 'fair' | 'poor';
  tollCost: number;
  isActive: boolean;
  safetyScore: number;
  carbonFootprint: number;
  alternativeRoutes: string[];
  historicalReliability: number;
  congestionPrediction: number;
  costEfficiency: number;
  timeEfficiency: number;
}

export interface Supplier {
  id: string;
  name: string;
  location: string;
  reliability: number;
  leadTime: number;
  costPerUnit: number;
  maxCapacity: number;
  qualityRating: number;
  sustainabilityScore: number;
  contractTerms: {
    minimumOrder: number;
    maximumOrder: number;
    paymentTerms: string;
    deliveryTerms: string;
    sustainabilityRequirements: string[];
    qualityStandards: string[];
  };
  certifications: string[];
  riskProfile: {
    financialStability: number;
    geopoliticalRisk: number;
    climateRisk: number;
    cyberSecurityRisk: number;
  };
  innovation: {
    technologyAdoption: number;
    r_and_d_investment: number;
    patentPortfolio: number;
    digitalMaturity: number;
  };
  performanceHistory: {
    onTimeDelivery: number;
    qualityScore: number;
    costStability: number;
    responsiveness: number;
  };
}

export interface Customer {
  id: string;
  location: string;
  demandPattern: 'stable' | 'seasonal' | 'volatile' | 'trending';
  priorityLevel: 'standard' | 'premium' | 'vip' | 'enterprise';
  satisfactionScore: number;
  orderHistory: Array<{
    date: Date;
    quantity: number;
    value: number;
    deliveryTime: number;
    satisfaction: number;
  }>;
  preferences: {
    sustainabilityImportance: number;
    pricesensitivity: number;
    speedImportance: number;
    qualityImportance: number;
  };
  demographics: {
    ageGroup: string;
    incomeLevel: string;
    educationLevel: string;
    environmentalAwareness: number;
  };
  digitalEngagement: {
    appUsage: number;
    onlineOrderPercent: number;
    socialMediaInfluence: number;
    techSavviness: number;
  };
  predictedLifetimeValue: number;
  churnRisk: number;
}

export interface SustainabilityMetrics {
  carbonFootprint: number;
  energyConsumption: number;
  renewableEnergyPercent: number;
  wasteGeneration: number;
  recyclingRate: number;
  waterUsage: number;
  biodiversityImpact: number;
  circularEconomyScore: number;
  socialImpact: {
    jobsCreated: number;
    localSourcing: number;
    communityInvestment: number;
    diversityIndex: number;
  };
  governanceScore: number;
  transparencyIndex: number;
  certifications: string[];
  goals: {
    carbonNeutralBy: number;
    renewableEnergyTarget: number;
    wasteReductionTarget: number;
  };
}

export interface InnovationMetrics {
  automationLevel: number;
  aiAdoptionRate: number;
  digitalTransformationScore: number;
  innovationPipeline: {
    projectsInDevelopment: number;
    patentsApplied: number;
    r_and_d_investment: number;
    timeToMarket: number;
  };
  technologyStack: {
    cloudAdoption: number;
    iotDevices: number;
    blockchainImplementation: number;
    quantumReadiness: number;
  };
  futureReadiness: {
    skillsGap: number;
    adaptabilityScore: number;
    resilienceIndex: number;
    disruptionPreparedness: number;
  };
  competitiveAdvantage: {
    technologyLeadership: number;
    innovationSpeed: number;
    marketDisruption: number;
  };
}

export interface PredictiveModel {
  id: string;
  name: string;
  type: 'regression' | 'classification' | 'time-series' | 'reinforcement-learning' | 'deep-learning' | 'ensemble';
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  lastTrainingDate: Date;
  trainingDataSize: number;
  features: string[];
  hyperparameters: Record<string, any>;
  validationMetrics: Record<string, number>;
  interpretability: {
    featureImportance: Record<string, number>;
    shap_values: Record<string, number>;
    lime_explanations: string[];
  };
  fairness: {
    demographicParity: number;
    equalizedOdds: number;
    calibration: number;
  };
  robustness: {
    adversarialAccuracy: number;
    noiseResistance: number;
    distributionShift: number;
  };
  deploymentMetrics: {
    latency: number;
    throughput: number;
    resourceUsage: number;
    costPerPrediction: number;
  };
}

export interface SupplyChainRisk {
  id: string;
  type: 'operational' | 'financial' | 'strategic' | 'compliance' | 'reputational';
  description: string;
  probability: number;
  impact: number;
  riskScore: number;
  affectedAreas: string[];
  mitigationStrategies: string[];
  contingencyPlans: string[];
  monitoringMetrics: string[];
  lastAssessment: Date;
  owner: string;
  status: 'identified' | 'assessed' | 'mitigated' | 'monitored' | 'closed';
}

export interface ComplianceMetric {
  id: string;
  regulation: string;
  complianceScore: number;
  lastAudit: Date;
  nextAudit: Date;
  violations: number;
  remedialActions: string[];
  certificationStatus: 'compliant' | 'non-compliant' | 'pending' | 'expired';
  associatedCosts: number;
  businessImpact: number;
}